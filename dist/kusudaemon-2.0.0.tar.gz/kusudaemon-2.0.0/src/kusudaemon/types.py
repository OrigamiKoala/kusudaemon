"""Shared types for the recursive-decomposition harness."""


from __future__ import annotations

import os
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Literal


def _launch_directory() -> str:
    """Directory kusudaemon was started from, captured once at import."""
    try:
        return str(Path.cwd())
    except OSError:
        return os.environ.get("PWD") or "."


DEFAULT_WORKSPACE_PATH = _launch_directory()
# Runs and temp state live under $HOME/.kusudaemon — harness-owned state
# is never stored inside the project it was launched from (matches
# pipeline/run.py's ~/.kusudaemon/runs default).
DEFAULT_TMP_DIR = f"{Path.home() / '.kusudaemon'}/tmp"


@dataclass
class ExecResult:
    stdout: str
    stderr: str
    exit_code: int
    duration_ms: int
    termination_reason: str | None = None


@dataclass
class EpisodeBudget:
    max_duration_seconds: int = 1800
    max_output_tokens: int | None = None

    def __post_init__(self) -> None:
        if self.max_duration_seconds < 1:
            raise ValueError("max_duration_seconds must be at least 1")
        if self.max_output_tokens is not None and self.max_output_tokens < 1:
            raise ValueError("max_output_tokens must be at least 1")


@dataclass
class EpisodeResult:
    status: Literal["done", "timeout", "error", "cancelled", "throttled"]
    actions_log: str = ""
    error: str | None = None
    duration_ms: int = 0
    metadata: dict[str, Any] = field(default_factory=dict)