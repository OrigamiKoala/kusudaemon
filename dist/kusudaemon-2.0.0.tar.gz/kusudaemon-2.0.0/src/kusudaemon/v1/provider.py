"""OpenAI-compatible provider layer (PLAN.md §12).

Scope for v1: OpenAI-compatible chat-completions endpoints only, tested
against DeepSeek V4 Flash Free via OpenCode Zen. Deliberately **not** a
provider abstraction: everything provider-specific lives in this one
module, un-abstracted, per §12 — "later portability costs one file instead
of a refactor."

Two things this module owns:

- ``complete`` — a plain chat completion, exposing ``reasoning_content``
  alongside ``content`` (§12: "Reasoning arrives as ``reasoning_content``
  alongside ``content`` in the delta").
- ``complete_json`` — the schema-constrained structured-output call used by
  Orchestrator/Reviewer (§13 v1 scope). ``response_format: json_schema``
  support varies by endpoint, so this always *also* validates the parsed
  response against the schema and re-prompts with the validator's error on
  failure, catching semantically-invalid-but-syntactically-valid output too
  (§12: "Build the fallback regardless").
"""

from __future__ import annotations

import copy
import json
import os
import re
import random
import threading
import time
import urllib.error
import urllib.request
from contextlib import contextmanager
from dataclasses import dataclass, field
from typing import Any, Callable, Iterable, Iterator

from ..degeneration import DegenerationMonitor, degeneration_reason, guard_enabled
from .gates import estimate_tokens
from .json_schema import describe_schema, validate
from ..provider_config import require, resolve

# PLAN-SWEEP-REPAIR.md §L.2: per-call overrides that don't widen the
# RoleProvider protocol. The event-driven orchestrator shares the run's main
# provider instance with other roles, so stamping ``provider.role`` would race;
# a thread-local scope applies only to calls made on the thread that opened it
# (the orchestrator's call runs on its own ``asyncio.to_thread`` worker).
_CALL_SCOPE = threading.local()


@contextmanager
def call_scope(
    *, role: str | None = None, max_tokens: int | None = None, node: str | None = None
) -> Iterator[None]:
    """Within the block, calls on this thread record ``role``, ``node``, and default to ``max_tokens``."""
    prev = (
        getattr(_CALL_SCOPE, "role", None),
        getattr(_CALL_SCOPE, "max_tokens", None),
        getattr(_CALL_SCOPE, "node", None),
    )
    _CALL_SCOPE.role = role if role is not None else prev[0]
    _CALL_SCOPE.max_tokens = max_tokens if max_tokens is not None else prev[1]
    _CALL_SCOPE.node = node if node is not None else prev[2]
    try:
        yield
    finally:
        _CALL_SCOPE.role, _CALL_SCOPE.max_tokens, _CALL_SCOPE.node = prev


def _scoped_role(default: str | None) -> str | None:
    return getattr(_CALL_SCOPE, "role", None) or default


def _scoped_node(default: str | None) -> str | None:
    return getattr(_CALL_SCOPE, "node", None) or default


def _scoped_max_tokens() -> int | None:
    return getattr(_CALL_SCOPE, "max_tokens", None)

# Defaults: OpenCode Zen (see ..provider_config — the user can override via
# ./provider.json, KUSUDAEMON_PROVIDER_*, or OPENAI_* env vars).
_DEFAULT_STRUCTURED_RETRIES = 2
# §P3: upper bound for the cap-escalation ladder in ``complete_json``.
_MAX_STRUCTURED_TOKENS = 32768

# A deadline and a truncation are different failures with different remedies,
# and until 2026-09-18 both were answered by doubling the output cap.
# Truncation genuinely needs more room. A deadline does not: the response was
# not cut off, the model simply spent the wall clock deliberating -- and since
# ``deadline_s`` is derived from the cap (``max(300, cap / min_tps)``), each
# doubling hands the next attempt a LONGER deadline to deliberate into. On a
# reasoning model that ladder ran 300 -> 300 -> 546 -> 1092 -> 2185s, which is
# how a bounded classify call (one small fixed JSON object) came to take
# 1751s of a 5400s run budget. Verdict roles already had the right remedy for
# a deadline -- tell the model to stop and emit -- so every role uses it now,
# and the cap is escalated only by truncation, which is the signal that
# actually means "needs more room".
_EMIT_NOW_NUDGE = "Stop deliberating. Emit the JSON now."

# 2026-09-26: how much of a cut-off answer's own reasoning is carried into the
# emit-now retry. The tail is kept because that is where a deliberation's
# conclusions sit; ~12k chars is ~3k tokens of extra prompt.
_CARRY_FORWARD_CHARS = 12_000


def _carry_forward(partial: str, nudge: str) -> list[dict[str, str]]:
    """Messages that resume a cut-off role call instead of restarting it.

    Before this, a response that hit the output ceiling or the deadline was
    thrown away and the model deliberated again from nothing (classify spent
    4096 + 8192 + 16384 tokens re-deriving the same estimate on 264-menu-week
    seed 2). The retry now sees the tail of its own reasoning as an assistant
    turn, then the nudge."""
    tail = (partial or "").strip()
    # 2026-09-26: never feed garbage back. A cut-off attempt whose tail is
    # script soup or a loop would prime the retry to continue it, so the
    # retry restarts from the original messages plus the nudge instead.
    if not tail or (guard_enabled() and degeneration_reason(tail)):
        return [{"role": "user", "content": nudge}]
    if len(tail) > _CARRY_FORWARD_CHARS:
        tail = "[...earlier reasoning omitted...]\n" + tail[-_CARRY_FORWARD_CHARS:]
    return [
        {"role": "assistant", "content": f"(My reasoning so far, cut off before I answered:)\n{tail}"},
        {"role": "user", "content": nudge},
    ]


# 2026-09-26: role caps sized so this reasoning model can finish deliberating
# and still emit JSON. The orchestrator's 1024 (C2) was spent on reasoning
# every time, so every call fell back to document order.
_ORCHESTRATOR_MAX_TOKENS_DEFAULT = 16384
_CLASSIFY_MAX_TOKENS_DEFAULT = 16384


def _classify_max_tokens() -> int:
    try:
        return max(1, int(os.getenv("KUSUDAEMON_CLASSIFY_MAX_TOKENS", str(_CLASSIFY_MAX_TOKENS_DEFAULT))))
    except ValueError:
        return _CLASSIFY_MAX_TOKENS_DEFAULT


_ORCHESTRATOR_DEADLINE_DEFAULT_S = 90.0


def orchestrator_decision_deadline_s() -> float:
    """Wall clock for one whole orchestrator decision, retries included.

    2026-09-26: back to a short default (the cap-scaled ~1092 s let one
    decision take 611 s). The round loop waits this long, and
    ``complete_json`` spends at most this long, so a call it gives up on does
    not keep running and block the next decision. ``<= 0`` means no deadline.
    """
    try:
        return float(os.getenv("KUSUDAEMON_ORCHESTRATOR_DEADLINE_S", str(_ORCHESTRATOR_DEADLINE_DEFAULT_S)))
    except ValueError:
        return _ORCHESTRATOR_DEADLINE_DEFAULT_S


# 2026-09-26: sampling for role calls. They were greedy (temperature 0.0),
# which is how this reasoning model ends up in loops like "week 2 is 8-14,
# week 2 is 8-14, ..." or one reviewer sentence repeated for 30k chars.
# Callers that pass no temperature get these; an explicit value (the
# reviewer's 0.7 second-opinion sample) is kept as given.
# KUSUDAEMON_ROLE_TOP_P=none leaves top_p out of the request.
_ROLE_TEMPERATURE_DEFAULT = 0.6
_ROLE_TOP_P_DEFAULT = 0.95


def role_sampling() -> tuple[float, float | None]:
    """(temperature, top_p) for a role call that did not choose its own."""
    try:
        temperature = float(os.getenv("KUSUDAEMON_ROLE_TEMPERATURE", str(_ROLE_TEMPERATURE_DEFAULT)))
    except ValueError:
        temperature = _ROLE_TEMPERATURE_DEFAULT
    raw_top_p = os.getenv("KUSUDAEMON_ROLE_TOP_P", str(_ROLE_TOP_P_DEFAULT)).strip().lower()
    if raw_top_p in ("", "none", "off"):
        return temperature, None
    try:
        return temperature, float(raw_top_p)
    except ValueError:
        return temperature, _ROLE_TOP_P_DEFAULT


def _apply_sampling(payload: dict[str, Any], temperature: float | None) -> None:
    default_temperature, top_p = role_sampling()
    payload["temperature"] = default_temperature if temperature is None else temperature
    if top_p is not None:
        payload["top_p"] = top_p


def _degenerate_retry_budget() -> int:
    """Fresh restarts per ``complete_json`` after degenerate output."""
    try:
        return max(0, int(os.getenv("KUSUDAEMON_DEGENERATE_RETRIES", "2")))
    except ValueError:
        return 2


def _deadline_retry_budget() -> int:
    """Deadline retries allowed per ``complete_json`` for a non-verdict role."""
    try:
        return max(0, int(os.getenv("KUSUDAEMON_ROLE_DEADLINE_RETRIES", "1")))
    except ValueError:
        return 1
_DEFAULT_HTTP_RETRIES = 3
_DEFAULT_CONCURRENCY = 4

# §D11 (2026-08-11): the rate-limit retry ladder — the operator-specified
# schedule for when a provider call comes back 429. Six rungs, in order:
# 1 m, 5 m, 30 m, 1 h, 3 h, 5 h. ``_call`` makes an initial attempt, then on
# each 429 sleeps the rung indexed by how many rate-limit retries have
# already happened and tries again — seven HTTP attempts in total when every
# one fails, after which the next 429 re-raises ``ProviderHTTPError``. That
# exception propagates through ``complete_json`` (which only swallows 400s)
# and out of whichever phase made the call; the driver's ``_run_phase`` then
# marks the phase ``error`` and ``run()`` breaks out of its phase loop —
# i.e. the task stops. A later ``resume`` re-enters that phase with a fresh
# ladder, which is the intended shape for a patient retry against a free-tier
# endpoint whose cooldown window may be measured in hours.
#
# Five hundred errors are *not* routed through this ladder: a transient 5xx
# is a server problem, not a rate limit, and waiting an hour to retry a 500
# is wrong. They keep the short exponential loop below.
RATE_LIMIT_BACKOFFS = (60.0, 300.0, 1800.0, 3600.0, 10800.0, 18000.0)


class ProviderError(RuntimeError):
    pass


class ProviderDeadlineError(ProviderError):
    """SSE stream wall-clock deadline exceeded (PLAN-REVIEW-READ-LOOP.md §R1).

    ``partial`` is whatever reasoning/content streamed before the deadline, so
    a retry can carry it forward instead of re-deliberating from scratch."""

    def __init__(self, message: str, partial: str = "") -> None:
        super().__init__(message)
        self.partial = partial


class ProviderReasoningBudgetError(ProviderDeadlineError):
    """A role call's streamed reasoning passed its budget; ``partial`` holds it."""


class ProviderDegenerateError(ProviderDeadlineError):
    """The stream turned to garbage (``degeneration.py``); ``reason`` says how."""

    def __init__(self, message: str, partial: str = "", reason: str = "") -> None:
        super().__init__(message, partial)
        self.reason = reason


# 2026-09-26: per-role reasoning control. Role calls on this reasoning model
# spent 1-8k tokens choosing among <= 3 nodes (orchestrator) and 4-11k before a
# ~100-token estimate (classify), at 6-40 tok/s on NIM, and nothing in the
# request limited it. ``KUSUDAEMON_REASONING_<ROLE>`` takes ``on``, ``off``
# and ``budget:N``, combined with commas (``off,budget:512``):
#   off       -- send ``KUSUDAEMON_REASONING_OFF_PAYLOAD`` (default: the
#                ``chat_template_kwargs.enable_thinking=false`` switch that
#                vLLM/NIM chat templates read). Unverified against this
#                endpoint; a 400 drops it for the provider's lifetime, and an
#                endpoint that ignores it costs nothing.
#   budget:N  -- client side and model-agnostic: once ~N tokens of reasoning
#                have streamed, the call is cut and resumed with its own
#                reasoning carried forward plus the emit-now nudge.
_REASONING_DEFAULTS = {"orchestrator": "off,budget:512", "classify": "budget:3072"}
_REASONING_OFF_PAYLOAD_DEFAULT: dict[str, Any] = {"chat_template_kwargs": {"enable_thinking": False}}


@dataclass(frozen=True)
class ReasoningSettings:
    thinking_off: bool = False
    budget_tokens: int | None = None


def role_reasoning(role: str | None) -> ReasoningSettings:
    key = re.sub(r"[^A-Za-z0-9]", "_", role or "").upper()
    raw = os.getenv(f"KUSUDAEMON_REASONING_{key}") if key else None
    if raw is None:
        raw = _REASONING_DEFAULTS.get(role or "", "on")
    off, budget = False, None
    for token in re.split(r"[,+\s]+", raw.strip().lower()):
        if token == "off":
            off = True
        elif token == "on":
            off = False
        elif token.startswith("budget:"):
            try:
                n = int(token.split(":", 1)[1])
            except ValueError:
                continue
            budget = n if n > 0 else None
    return ReasoningSettings(thinking_off=off, budget_tokens=budget)


def _reasoning_off_payload() -> dict[str, Any]:
    raw = os.getenv("KUSUDAEMON_REASONING_OFF_PAYLOAD")
    if raw:
        try:
            value = json.loads(raw)
        except json.JSONDecodeError:
            value = None
        if isinstance(value, dict):
            return value
    return copy.deepcopy(_REASONING_OFF_PAYLOAD_DEFAULT)


def _reasoning_retry_budget() -> int:
    """Budget cuts resumed per ``complete_json``; the next cut raises."""
    try:
        return max(0, int(os.getenv("KUSUDAEMON_REASONING_BUDGET_RETRIES", "1")))
    except ValueError:
        return 1


class ProviderHTTPError(ProviderError):
    """HTTP-level rejection from the endpoint, carrying its status code.

    lets callers react to specific statuses (e.g. `complete_json` retrying
    a 400 without `response_format`) instead of string-matching messages
    (PLAN-zeromem.md §11.3). ``retry_after`` carries the endpoint's
    ``Retry-After`` header (seconds) when the failed response had one, so
    the §11.10.3 / §D11 backoff paths can honor it.
    """

    def __init__(self, status: int, message: str, retry_after: float | None = None) -> None:
        super().__init__(message)
        self.status = status
        self.retry_after = retry_after


@dataclass
class ProviderResponse:
    content: str
    reasoning_content: str = ""
    raw: dict[str, Any] = field(default_factory=dict)


# (url, json_payload, headers) -> parsed JSON response body. Swappable so
# tests never need a real network call or API key.
Transport = Callable[[str, dict[str, Any], dict[str, str]], dict[str, Any]]


from ..roles.json_io import (
    _parse_json_object,
    _repair_common_schema_omissions,
    _unwrap_schema_echo,
    extract_last_json_object,
)
from ..roles.protocol import RoleProviderBase


class OpenAICompatibleProvider(RoleProviderBase):
    """Thin client for Orchestrator/Planner/Reviewer direct-API calls.

    Knows nothing about roles or role/model routing (§12: "a config table,
    not code") — callers pass whatever ``model`` they've routed to.
    """

    def __init__(
        self,
        *,
        provider: str | None = None,
        model: str | None = None,
        base_url: str | None = None,
        api_key: str | None = None,
        transport: Transport | None = None,
        stream_transport: Callable[
            [str, dict[str, Any], dict[str, str], Callable[[str], None] | None],
            dict[str, Any],
        ]
        | None = None,
        timeout: float = 120.0,
        max_http_retries: int = _DEFAULT_HTTP_RETRIES,
        base_retry_delay: float = 1.0,
        concurrency: int = _DEFAULT_CONCURRENCY,
        sleep: Callable[[float], None] = time.sleep,
        on_backoff: Callable[[int, float], None] | None = None,
        should_abort: Callable[[], bool] | None = None,
        on_model_fallback: Callable[[str, str, str], None] | None = None,
        cost_ledger: Any = None,
        role: str = "unknown",
        phase: str = "unknown",
        node_id: str = "-",
        on_usage: Callable[[int, int, int], None] | None = None,
        admission_controller: Any | None = None,
    ) -> None:
        self.admission_controller = admission_controller
        resolved = resolve(provider=provider or "", api_key=api_key or "", base_url=base_url or "", model=model or "")
        self.model = resolved.model
        if self.model and self.model.startswith("nvidia/nvidia/"):
            self.model = self.model.removeprefix("nvidia/")
        self.base_url = resolved.base_url.rstrip("/")
        self.api_key = resolved.api_key
        raw_env_timeout = os.getenv("KUSUDAEMON_HTTP_TIMEOUT")
        if raw_env_timeout:
            try:
                self.timeout = float(raw_env_timeout)
            except ValueError:
                self.timeout = timeout
        else:
            self.timeout = timeout
        self._transport = transport or self._http_transport
        self._stream_transport_impl = stream_transport or self._http_stream_transport
        self._max_http_retries = max_http_retries
        self._base_retry_delay = base_retry_delay
        self._sleep = sleep
        # §D11: callbacks fired with (1-based attempt number, delay seconds)
        # just before each rung of the rate-limit ladder sleeps — purely an
        # observability seam: a phase stuck mid-call for up to five hours
        # otherwise shows as a silent ``in_progress`` with nothing explaining
        # what's happening. The driver wires it through to ``events.jsonl`` at
        # its construction sites (the main CLI ``run`` and a hosted run's
        # ``_default_driver``). Default ``None`` keeps behavior byte-identical
        # otherwise; the ladder runs regardless of whether anyone's told about
        # it.
        self._on_backoff = on_backoff
        self._should_abort = should_abort
        self._on_model_fallback = on_model_fallback
        self.cost_ledger = cost_ledger
        self.role = role
        self.phase = phase
        self.node_id = node_id
        self.on_usage = on_usage
        # §11.10.2 / A4-1: remember whether this endpoint supports
        # `response_format: {type: json_schema, ...}` across calls on the
        # same provider instance. Defaults to `None` (untested) — the first
        # call on an endpoint that rejects `response_format` burns a wasted
        # HTTP request first, a literal 2× on request count for the entire
        # Direct column.
        self._response_format_ok: bool | None = None
        # 2026-09-26: ``False`` once the endpoint 400s a request carrying the
        # reasoning-off switch; later calls stop sending it.
        self._reasoning_switch_ok: bool | None = None
        # A3-2: `True` once some complete_json call returned schema-valid
        # JSON under `response_format` — the endpoint has proven it enforces
        # the schema, so later calls can drop the prose schema copy. `None`
        # = no proof yet; `False` is unreachable (a 400 flips
        # `_response_format_ok` and the endpoint never sees the field again).
        self._format_supported: bool | None = None
        # §11.10.3: concurrent callers (parallel tests, the dashboard, two
        # drivers on one endpoint) share one throttle, so a 429 storm from
        # one run can't starve the endpoint for the other.
        self._throttle = threading.Semaphore(max(1, concurrency))

    def _report_schema_failure(
        self,
        error: str,
        *,
        content: str,
        reasoning: str,
        attempt: int,
        parsed: Any = None,
        head_chars: int = 1500,
    ) -> None:
        """LONGGENBENCH-RESULTS-2026-09 §4.1 item 4: raw responses were never
        logged, so "$.action: missing required property" (13 cells) could not
        be diagnosed. Emits a ``role_schema_failure`` event carrying the head
        and tail of the raw content and the parsed keys. It rides the
        degenerate hook (whose ``**info`` overrides the event ``type``), so no
        second hook has to be wired through the role-provider proxies. Never
        raises."""
        hook = getattr(self, "_on_degenerate", None)
        if hook is None:
            return
        try:
            hook({
                "type": "role_schema_failure",
                "error": str(error)[:500],
                "attempt": attempt,
                "content_chars": len(content),
                "content_head": content[:head_chars],
                "content_tail": content[-head_chars:] if len(content) > head_chars else "",
                "reasoning_chars": len(reasoning),
                "parsed_keys": sorted(parsed.keys()) if isinstance(parsed, dict) else None,
                "role": _scoped_role(self.role),
                "phase": self.phase,
                "call_node": _scoped_node(self.node_id),
                "model": self.model,
            })
        except Exception:  # noqa: BLE001 — observability only
            pass

    def _report_degenerate(self, reason: str, *, chars: int, action: str) -> None:
        """Tell the driver (``role_output_degenerate`` event); never raises."""
        hook = getattr(self, "_on_degenerate", None)
        if hook is None:
            return
        try:
            hook({
                "reason": reason,
                "action": action,
                "chars": chars,
                "role": _scoped_role(self.role),
                "phase": self.phase,
                "call_node": _scoped_node(self.node_id),
                "model": self.model,
            })
        except Exception:  # noqa: BLE001 -- observability only
            pass

    def _record_usage(self, payload: dict[str, Any], raw: dict[str, Any], content: str) -> None:
        usage = raw.get("usage") if isinstance(raw, dict) else None
        estimated = False
        if usage and isinstance(usage, dict):
            prompt_tokens = int(usage.get("prompt_tokens", 0) or 0)
            completion_tokens = int(usage.get("completion_tokens", 0) or 0)
            reasoning_tokens = int(usage.get("completion_tokens_details", {}).get("reasoning_tokens", 0) or 0)
        else:
            prompt_tokens = estimate_tokens(str(payload.get("messages", "")))
            prompt_tokens = max(1, prompt_tokens)
            completion_tokens = max(1, estimate_tokens(content))
            reasoning_tokens = 0
            estimated = True
        if self.cost_ledger is not None and hasattr(self.cost_ledger, "record"):
            self.cost_ledger.record(
                role=_scoped_role(self.role),
                phase=self.phase,
                node=_scoped_node(self.node_id),
                model=self.model,
                prompt_tokens=prompt_tokens,
                completion_tokens=completion_tokens,
                reasoning_tokens=reasoning_tokens,
                estimated=estimated,
            )
        if self.on_usage is not None:
            self.on_usage({
                "model": self.model,
                "prompt_tokens": prompt_tokens,
                "completion_tokens": completion_tokens,
                "reasoning_tokens": reasoning_tokens,
            })

    def complete(
        self,
        messages: list[dict[str, str]],
        *,
        temperature: float | None = None,
        max_tokens: int | None = None,
    ) -> ProviderResponse:
        payload: dict[str, Any] = {
            "model": self.model,
            "messages": messages,
            "stream": False,
        }
        _apply_sampling(payload, temperature)
        effective_max = max_tokens
        if effective_max is None and os.getenv("KUSUDAEMON_ROLE_MAX_TOKENS"):
            try:
                effective_max = int(os.environ["KUSUDAEMON_ROLE_MAX_TOKENS"])
            except ValueError:
                pass
        if effective_max is not None:
            payload["max_tokens"] = effective_max

        raw = self._call(payload)
        message = _first_choice_message(raw)
        content = message.get("content") or ""
        self._record_usage(payload, raw, content)
        return ProviderResponse(
            content=content,
            reasoning_content=message.get("reasoning_content") or "",
            raw=raw,
        )

    def complete_json(
        self,
        messages: list[dict[str, str]],
        schema: dict[str, Any],
        *,
        temperature: float | None = None,
        retries: int = _DEFAULT_STRUCTURED_RETRIES,
        on_reasoning: Callable[[str], None] | None = None,
        streaming: bool = False,
        max_tokens: int | None = None,
    ) -> dict[str, Any]:
        base_messages: list[dict[str, str]] = list(messages)
        # The one carry-forward block for a cut-off response (see
        # ``_carry_forward``). Replaced, never appended, on each retry: the
        # latest partial already builds on the previous one, so the prompt
        # grows by at most one bounded block (§P3's no-growth concern).
        resume: list[dict[str, str]] = []
        last_error = "empty response"

        def make_messages(with_format: bool) -> list[dict[str, str]]:
            if with_format and self._format_supported is True:
                # A3-2 (IMPLEMENTATION-PLAN-COST-AND-LIVE.md): once one call
                # has returned schema-valid JSON *with* response_format set,
                # the endpoint has proven it enforces the schema itself — the
                # 170-240-token prose copy is redundant and gets dropped.
                # Before that proof (and on any formatless fallback) the prose
                # stays, because nothing else carries the schema then.
                return [*base_messages, *resume]
            return [
                {
                    "role": "system",
                    "content": (
                        "Respond with a single JSON object only — no prose, no "
                        f"code fences — matching this schema:\n{describe_schema(schema)}"
                    ),
                },
                *base_messages,
                *resume,
            ]

        def _default_max_tokens(sch: dict[str, Any]) -> int:
            current_role = _scoped_role(self.role)
            if current_role == "orchestrator":
                return _ORCHESTRATOR_MAX_TOKENS_DEFAULT
            props = sch.get("properties") or {}
            if len(props) <= 4 and all(
                isinstance(p, dict) and p.get("type") in ("string", "integer", "number", "boolean")
                for p in props.values()
            ):
                return 2048
            if "questions" in props or "objections" in props:
                # Classify / intake. 2026-09-26: 16384 (was 4096). This
                # model deliberates 4-11k tokens over a LongGenBench goal
                # before emitting JSON, so 4096 cut off nearly every call.
                return _classify_max_tokens()
            return 8192

        effective_max_tokens = max_tokens if max_tokens is not None else _scoped_max_tokens()
        if effective_max_tokens is None and os.getenv("KUSUDAEMON_ROLE_MAX_TOKENS"):
            try:
                effective_max_tokens = int(os.environ["KUSUDAEMON_ROLE_MAX_TOKENS"])
            except ValueError:
                pass
        if effective_max_tokens is None:
            effective_max_tokens = _default_max_tokens(schema)
        # §P3: mutable across attempts — a response that stopped at the ceiling
        # is retried with a bigger ceiling, not with the same one plus a
        # "that did not validate" turn that only grows the prompt.
        cap = {"max_tokens": effective_max_tokens}

        def make_payload(with_format: bool) -> dict[str, Any]:
            payload: dict[str, Any] = {
                "model": self.model,
                "messages": make_messages(with_format),
                "stream": streaming,
            }
            _apply_sampling(payload, temperature)
            if cap["max_tokens"]:
                payload["max_tokens"] = cap["max_tokens"]

            if streaming:
                payload["stream_options"] = {"include_usage": True}
            if reasoning.thinking_off and self._reasoning_switch_ok is not False:
                payload.update(_reasoning_off_payload())
            if with_format:
                payload["response_format"] = {
                    "type": "json_schema",
                    "json_schema": {"name": "response", "schema": schema, "strict": True},
                }
            return payload

        # §11.10.2: latch the fallback after the first 400 — an endpoint
        # that rejects `response_format` costs one structured-retry per
        # validate-reprompt attempt, not two HTTP requests per attempt.
        # A4-1: the latch is instance state now — once an endpoint 400s,
        # every later complete_json call skips the field outright instead of
        # re-learning the rejection on its first request.
        use_format = self._response_format_ok is not False
        current_role = _scoped_role(self.role)
        is_verdict_role = current_role in ("reviewer", "triage")

        validation_attempts = 0
        cap_escalations = 0
        truncation_retries = 0
        deadline_retries = 0
        empty_retries = 0
        verdict_deadline_retried = False
        degenerate_retries = 0

        orchestrator_budget = (
            orchestrator_decision_deadline_s() if current_role == "orchestrator" else 0.0
        )
        call_started = time.monotonic()
        reasoning = role_reasoning(current_role)
        budget_retries = 0
        emit_nudge = "Stop deliberating. Emit the JSON verdict now." if is_verdict_role else _EMIT_NOW_NUDGE

        def attempt_sink() -> Callable[[str], None] | None:
            """``on_reasoning`` for one attempt, enforcing the reasoning budget
            and cutting the stream as soon as it degenerates."""
            guard = guard_enabled()
            if not streaming or not (reasoning.budget_tokens or guard):
                return on_reasoning
            limit_chars = reasoning.budget_tokens * 4 if reasoning.budget_tokens else None
            monitor = DegenerationMonitor() if guard else None
            seen: list[str] = []
            count = [0]

            def sink(text: str) -> None:
                if on_reasoning is not None:
                    on_reasoning(text)
                seen.append(text)
                count[0] += len(text)
                if monitor is not None:
                    why = monitor.feed(text)
                    if why:
                        raise ProviderDegenerateError(
                            f"reasoning degenerated ({why}) after {count[0]} chars",
                            partial="".join(seen),
                            reason=why,
                        )
                if limit_chars is not None and count[0] > limit_chars:
                    raise ProviderReasoningBudgetError(
                        f"reasoning passed its budget (~{reasoning.budget_tokens} tokens)",
                        partial="".join(seen),
                    )

            return sink

        def restart_after_degenerate(why: str, chars: int) -> bool:
            """Drop a garbage attempt and start over; False means give up."""
            nonlocal degenerate_retries, last_error
            retry = degenerate_retries < _degenerate_retry_budget()
            self._report_degenerate(why, chars=chars, action="restart" if retry else "gave_up")
            if not retry:
                return False
            degenerate_retries += 1
            last_error = f"output degenerated ({why}); restarting fresh"
            resume.clear()
            return True

        def resume_after_cut(pde: ProviderDeadlineError) -> bool:
            """Carry a cut-off attempt forward; False means give up and raise."""
            nonlocal budget_retries, deadline_retries, verdict_deadline_retried, last_error
            if isinstance(pde, ProviderDegenerateError):
                return restart_after_degenerate(pde.reason, len(pde.partial))
            if isinstance(pde, ProviderReasoningBudgetError):
                if budget_retries >= _reasoning_retry_budget():
                    return False
                budget_retries += 1
            elif is_verdict_role:
                if verdict_deadline_retried:
                    return False
                verdict_deadline_retried = True
            elif deadline_retries < _deadline_retry_budget():
                deadline_retries += 1
            else:
                return False
            last_error = f"{pde}; retrying with emit instruction"
            resume[:] = _carry_forward(pde.partial, emit_nudge)
            return True

        while validation_attempts <= retries:
            curr_payload = make_payload(with_format=use_format)
            min_tps = float(os.getenv("KUSUDAEMON_MIN_DECODE_TPS", "15"))
            current_cap = cap["max_tokens"] or _default_max_tokens(schema)
            if orchestrator_budget > 0:
                # One budget for the whole decision: every retry below gets
                # only what is left of it.
                deadline_s = orchestrator_budget - (time.monotonic() - call_started)
                if deadline_s <= 0:
                    raise ProviderDeadlineError(
                        f"orchestrator decision budget ({orchestrator_budget:.0f}s) spent; last: {last_error}"
                    )
            elif current_role in ("reviewer", "triage"):
                deadline_s = float(os.getenv("KUSUDAEMON_REVIEWER_DEADLINE_S", "180.0"))
            else:
                deadline_s = max(300.0, current_cap / min_tps)
            sent_switch = reasoning.thinking_off and self._reasoning_switch_ok is not False
            try:
                raw = self._call(
                    curr_payload,
                    stream=streaming,
                    on_reasoning=attempt_sink(),
                    deadline_s=deadline_s,
                )
            except ProviderDeadlineError as pde:
                if resume_after_cut(pde):
                    continue
                raise
            except ProviderHTTPError as exc:
                if exc.status == 400 and sent_switch:
                    # The reasoning switch is the newer, unverified field, so
                    # it is dropped first; a second 400 reaches the
                    # response_format fallback below.
                    self._reasoning_switch_ok = False
                    last_error = f"endpoint rejected the reasoning switch: {exc}"
                    continue
                # §12's fallback must be reachable when the *endpoint* (not
                # the model) rejects structured output: some OpenAI-compatible
                # hosts 400 on `response_format` / `strict`. The system prompt
                # already describes the schema in prose, so retrying the same
                # messages without the field is fully functional
                # (PLAN-zeromem.md §11.3).
                if exc.status != 400:
                    raise
                self._response_format_ok = False
                use_format = False
                curr_payload = make_payload(with_format=False)
                try:
                    raw = self._call(
                        curr_payload,
                        stream=streaming,
                        on_reasoning=attempt_sink(),
                        deadline_s=deadline_s,
                    )
                except ProviderDeadlineError as pde:
                    if resume_after_cut(pde):
                        continue
                    raise
            message = _first_choice_message(raw)
            if not streaming and on_reasoning is not None:
                # (Named so it does not shadow ``reasoning``, the settings
                # object ``make_payload`` reads on the next attempt.)
                reasoning_text = message.get("reasoning_content")
                if reasoning_text:
                    on_reasoning(reasoning_text)
            content = message.get("content") or ""
            self._record_usage(curr_payload, raw, content)

            # PLAN-REVIEW-READ-LOOP.md §R1.6: Treat completion with completion_tokens <= 1 and empty content as transient transport failure
            usage = raw.get("usage") if isinstance(raw, dict) else {}
            comp_tokens = int(usage.get("completion_tokens", 0) or 0) if isinstance(usage, dict) else 0
            if comp_tokens <= 1 and not content.strip() and empty_retries < 3:
                empty_retries += 1
                # 2026-09-26: a stream that ends with reasoning and no answer
                # (classify and the orchestrator, ~600 s in, cut mid-sentence)
                # is resumed from that reasoning, not restarted from nothing.
                partial_reasoning = str(message.get("reasoning_content") or "")
                if partial_reasoning.strip():
                    last_error = "stream ended after reasoning with no answer; resuming with emit instruction"
                    resume[:] = _carry_forward(partial_reasoning, emit_nudge)
                else:
                    last_error = f"transient empty completion ({comp_tokens} tokens)"
                continue

            # §P3: before blaming the JSON, ask whether there was room for any.
            truncated = _hit_token_ceiling(raw, cap["max_tokens"])
            parsed, parse_error = extract_last_json_object(content, schema=schema)
            if parsed is None:
                parsed, parse_error = _parse_json_object(content)

            # PLAN-REVIEW-READ-LOOP.md §R1.4 / 2026-09-26: a response cut off at
            # the ceiling is resumed, not restarted -- the retry carries the
            # tail of its own reasoning forward plus an emit-now nudge. Verdict
            # roles get one such retry at the same cap. Other roles first
            # retry at the same cap; only a second cut-off doubles the cap
            # (still carrying forward), up to _MAX_STRUCTURED_TOKENS.
            partial = (message.get("reasoning_content") or "") + content
            # 2026-09-26: a finished response can be garbage too (a
            # non-streaming call, or content after clean reasoning). Unless it
            # still yields schema-valid JSON, restart fresh: the validation
            # reprompt below would put the garbage in the next prompt.
            degenerate = degeneration_reason(partial) if guard_enabled() else None
            if degenerate and (parsed is None or validate(
                _repair_common_schema_omissions(_unwrap_schema_echo(parsed, schema), schema), schema
            )):
                if restart_after_degenerate(degenerate, len(partial)):
                    continue
                last_error = f"output degenerated ({degenerate})"
                break
            if truncated:
                if is_verdict_role:
                    if not verdict_deadline_retried:
                        verdict_deadline_retried = True
                        last_error = "response truncated at ceiling; retrying with emit instruction"
                        resume[:] = _carry_forward(partial, "Stop deliberating. Emit the JSON verdict now.")
                        continue
                    last_error = f"response hit output ceiling ({cap['max_tokens']} tokens, the maximum) before JSON was complete"
                    if parsed is None:
                        break
                else:
                    # Retry even when the scanner found an object: a cut-off
                    # response's "JSON" can be a fragment quoted from its own
                    # reasoning (§R2, 343-block seed 3's fabricated estimate).
                    previous = cap["max_tokens"] or _default_max_tokens(schema)
                    if truncation_retries == 0:
                        truncation_retries += 1
                        last_error = (
                            f"response hit the output ceiling ({previous} tokens) before the "
                            "JSON was complete; resuming with emit instruction"
                        )
                        resume[:] = _carry_forward(partial, _EMIT_NOW_NUDGE)
                        continue
                    cap["max_tokens"] = min(previous * 2, _MAX_STRUCTURED_TOKENS)
                    if cap["max_tokens"] != previous:
                        cap_escalations += 1
                        last_error = (
                            f"response hit the output ceiling ({previous} tokens) before the "
                            f"JSON was complete; resuming at {cap['max_tokens']}"
                        )
                        resume[:] = _carry_forward(partial, _EMIT_NOW_NUDGE)
                        continue
                    last_error = (
                        f"response hit the output ceiling ({previous} tokens, the maximum) "
                        "before the JSON was complete"
                    )
                    if parsed is None:
                        break

            if parsed is not None:
                parsed = _repair_common_schema_omissions(_unwrap_schema_echo(parsed, schema), schema)
                schema_errors = validate(parsed, schema)
                if not schema_errors:
                    # A3-2: a schema-valid response under response_format is
                    # the proof that lets later calls drop the prose copy.
                    if use_format:
                        self._format_supported = True
                    return parsed
                last_error = "; ".join(schema_errors)
            else:
                last_error = parse_error

            self._report_schema_failure(
                last_error,
                content=content,
                reasoning=str(message.get("reasoning_content") or ""),
                attempt=validation_attempts + 1,
                parsed=parsed,
            )
            validation_attempts += 1
            if validation_attempts > retries:
                break

            # The response that did finish supersedes any carry-forward block;
            # keeping it would put stale reasoning after the reprompt below.
            resume.clear()
            base_messages = [
                *base_messages,
                {"role": "assistant", "content": content},
                {
                    "role": "user",
                    "content": f"That did not validate: {last_error}. Return corrected JSON only.",
                },
            ]
        raise ProviderError(
            f"structured output failed after {retries + 1} attempts: {last_error}"
        )

    def _call(
        self,
        payload: dict[str, Any],
        *,
        stream: bool = False,
        on_reasoning: Callable[[str], None] | None = None,
        deadline_s: float | None = None,
    ) -> dict[str, Any]:
        headers = {"Content-Type": "application/json", "User-Agent": "kusudaemon/1.0 (Python)"}
        if self.api_key:
            headers["Authorization"] = f"Bearer {self.api_key}"
        # §D11: 429 (rate limit) is the patient ladder case; 5xx keeps the
        # short exponential loop. Other 4xx is a caller bug and surfaces
        # immediately. §11.10.3's Retry-After honor survives in both branches:
        # on the 429 branch it can only *extend* a rung (never shrink it
        # below the operator-specified schedule), capped at the ladder's own
        # ceiling; on the 5xx branch it stays capped at 60s as before.
        attempt = 0
        # PLAN-SWEEP-REPAIR.md §F: transport failures get their own counter so
        # a 429 ladder that ran earlier in this call cannot silently consume
        # the socket-timeout budget (and vice versa).
        transport_attempt = 0
        switches = 0
        tried_models: set[str] = {self.model}
        while True:
            if self.admission_controller is not None:
                self.admission_controller.wait_sync()
            try:
                with self._throttle:
                    if stream:
                        import inspect

                        sig = inspect.signature(self._stream_transport_impl)
                        if "deadline_s" in sig.parameters or any(
                            p.kind == inspect.Parameter.VAR_KEYWORD
                            for p in sig.parameters.values()
                        ):
                            return self._stream_transport_impl(
                                f"{self.base_url}/chat/completions",
                                payload,
                                headers,
                                on_reasoning,
                                deadline_s=deadline_s,
                            )
                        return self._stream_transport_impl(
                            f"{self.base_url}/chat/completions", payload, headers, on_reasoning
                        )
                    return self._transport(f"{self.base_url}/chat/completions", payload, headers)
            except ProviderDeadlineError:
                # PLAN-REVIEW-READ-LOOP.md §R1.3: ProviderDeadlineError is not retried by transport branch
                raise
            except ProviderHTTPError as exc:
                if exc.status == 400 or (exc.status < 500 and exc.status != 429):
                    raise
                if exc.status == 429:
                    if self.admission_controller is not None:
                        delay_hint = exc.retry_after if exc.retry_after is not None else RATE_LIMIT_BACKOFFS[min(attempt, len(RATE_LIMIT_BACKOFFS) - 1)]
                        self.admission_controller.record_backoff(delay_hint)
                    # §G4: on the second 429 rung (attempt == 1), try a model fallback if configured
                    if attempt == 1 and switches < 4:
                        from ..provider_config import get_fallback_model, resolve as resolve_provider

                        fallback_model = get_fallback_model(self.model)
                        if fallback_model and fallback_model != self.model and fallback_model not in tried_models:
                            old_model = self.model
                            reason = f"429 rate limit on {old_model}"
                            try:
                                res = resolve_provider(model=fallback_model)
                                self.model = res.model
                                self.base_url = res.base_url.rstrip("/")
                                self.api_key = res.api_key
                                payload["model"] = self.model
                                tried_models.add(self.model)
                                switches += 1
                                if self._on_model_fallback is not None:
                                    self._on_model_fallback(old_model, self.model, reason)
                                attempt = 0
                                continue
                            except Exception:
                                pass

                    # ``attempt`` indexes the ladder rung we're about to
                    # sleep on (0-based); six rungs means seven HTTP attempts
                    # total when every one fails, and the rung-6 failure
                    # re-raises — the provider caller's phase machinery then
                    # stops the task (PLAN.md §10: error at a phase boundary).
                    if attempt >= len(RATE_LIMIT_BACKOFFS):
                        raise
                    delay = RATE_LIMIT_BACKOFFS[attempt]
                    if exc.retry_after is not None:
                        delay = max(delay, min(exc.retry_after, RATE_LIMIT_BACKOFFS[-1]))
                    if self._on_backoff is not None:
                        try:
                            self._on_backoff(attempt + 1, delay, reason="rate_limit")
                        except TypeError:
                            self._on_backoff(attempt + 1, delay)

                    # §E16: sliced interruptible sleep
                    total_sleep = delay * random.uniform(0.8, 1.2)
                    if self._should_abort is not None:
                        elapsed = 0.0
                        while elapsed < total_sleep:
                            if self._should_abort():
                                raise ProviderError("rate limit backoff aborted by halt signal")
                            step = min(5.0, total_sleep - elapsed)
                            self._sleep(step)
                            elapsed += step
                    else:
                        self._sleep(total_sleep)
                    attempt += 1
                    continue
                if attempt >= self._max_http_retries:
                    raise
                if exc.retry_after is not None:
                    delay = max(0.0, min(exc.retry_after, 60.0))
                else:
                    delay = self._base_retry_delay * (2 ** attempt)
                self._sleep(delay * random.uniform(0.8, 1.2))
                attempt += 1
            except ProviderError as exc:
                # PLAN-SWEEP-REPAIR.md §F: a socket read timeout, connection
                # reset or DNS failure surfaces from ``_http_transport`` as a
                # bare ``ProviderError``, not a ``ProviderHTTPError``. Before
                # this branch existed it matched none of the ladders above,
                # propagated through ``complete_json`` (which swallows only
                # 400s) and out of the phase — so one slow reviewer call
                # ended the whole run with ``error in execute: The read
                # operation timed out``. docs/PLAN-REVIEW-LATENCY.md T0-6 set
                # the reviewer's short budget expecting a slow call to "fail
                # fast into the retry rather than hold the wave"; this is that
                # retry, and it is what makes T0-6's premise true. Same short
                # exponential shape as the 5xx branch: transient network
                # trouble is a server/link problem, not a rate limit, so it
                # never enters the hours-long §D11 ladder.
                if transport_attempt >= self._max_http_retries:
                    raise
                delay = (
                    self._base_retry_delay * (2 ** transport_attempt) * random.uniform(0.8, 1.2)
                )
                if self._on_backoff is not None:
                    try:
                        self._on_backoff(transport_attempt + 1, delay, reason="transport")
                    except TypeError:
                        self._on_backoff(transport_attempt + 1, delay)
                # §E16: sliced interruptible sleep, so a halt signal is not
                # held for the length of the backoff.
                if self._should_abort is not None:
                    slept = 0.0
                    while slept < delay:
                        if self._should_abort():
                            raise ProviderError(
                                f"transport retry aborted by halt signal: {exc}"
                            ) from exc
                        step = min(5.0, delay - slept)
                        self._sleep(step)
                        slept += step
                else:
                    self._sleep(delay)
                transport_attempt += 1

    def _http_transport(
        self, url: str, payload: dict[str, Any], headers: dict[str, str]
    ) -> dict[str, Any]:
        body = json.dumps(payload).encode("utf-8")
        request = urllib.request.Request(url, data=body, headers=headers, method="POST")
        # PLAN-SWEEP-REPAIR.md §F2: name the phase, role and elapsed time at
        # the raise site so the next execute-phase halt is self-diagnosing
        # ("error in execute: The read operation timed out" today names none
        # of the three). Elapsed is measured around urlopen; the timeout value
        # is included so a reader can tell a slow endpoint from a short fuse.
        t0 = time.time()
        try:
            with urllib.request.urlopen(request, timeout=self.timeout) as response:
                return json.loads(response.read().decode("utf-8"))
        except urllib.error.HTTPError as exc:
            elapsed = time.time() - t0
            detail = exc.read().decode("utf-8", errors="replace")
            retry_after = _parse_retry_after(exc.headers.get("Retry-After"))
            raise ProviderHTTPError(
                exc.code,
                f"HTTP {exc.code} from provider"
                f" [phase={self.phase} role={_scoped_role(self.role)} node={_scoped_node(self.node_id)}"
                f" elapsed={elapsed:.1f}s timeout={self.timeout}s]: {detail[:500]}",
                retry_after=retry_after,
            ) from exc
        except (urllib.error.URLError, TimeoutError, OSError) as exc:
            elapsed = time.time() - t0
            reason = getattr(exc, "reason", exc)
            raise ProviderError(
                f"provider request failed"
                f" [phase={self.phase} role={_scoped_role(self.role)} node={_scoped_node(self.node_id)}"
                f" elapsed={elapsed:.1f}s timeout={self.timeout}s]: {reason}"
            ) from exc


    def _http_stream_transport(
        self,
        url: str,
        payload: dict[str, Any],
        headers: dict[str, str],
        on_reasoning: Callable[[str], None] | None,
        deadline_s: float | None = None,
    ) -> dict[str, Any]:
        """B3-1 (IMPLEMENTATION-PLAN-COST-AND-LIVE.md): the streaming twin of
        ``_http_transport``. Consumes the SSE delta stream, accumulates
        ``delta.content`` into the JSON buffer, and fires ``on_reasoning``
        per ``delta.reasoning_content``/``delta.reasoning`` chunk as it
        arrives — so a phase call's trace file grows live instead of only
        after the whole call completes. Returns the same synthetic
        ``{choices: [{message: ...}]}`` body ``_first_choice_message``
        consumes, so validation/reprompt logic upstream is unchanged."""
        body = json.dumps(payload).encode("utf-8")
        request = urllib.request.Request(url, data=body, headers=headers, method="POST")
        # PLAN-SWEEP-REPAIR.md §F2: same phase/role/elapsed context as
        # _http_transport for the streaming twin.
        t0 = time.time()
        effective_deadline = deadline_s
        if effective_deadline is None:
            cur_role = _scoped_role(self.role)
            if cur_role == "orchestrator" and orchestrator_decision_deadline_s() > 0:
                effective_deadline = orchestrator_decision_deadline_s()
            elif cur_role in ("reviewer", "triage"):
                effective_deadline = float(os.getenv("KUSUDAEMON_REVIEWER_DEADLINE_S", "180.0"))
            else:
                min_tps = float(os.getenv("KUSUDAEMON_MIN_DECODE_TPS", "15"))
                cap_tok = payload.get("max_tokens") or 4096
                effective_deadline = max(300.0, cap_tok / min_tps)
        try:
            # The deadline is only checked when a line arrives, so a stalled
            # stream also needs a socket read timeout no longer than it.
            read_timeout = self.timeout
            if effective_deadline and effective_deadline > 0:
                read_timeout = min(read_timeout or effective_deadline, effective_deadline)
            with urllib.request.urlopen(request, timeout=read_timeout) as response:
                lines = (line.decode("utf-8", errors="replace").rstrip("\n") for line in response)
                return _consume_sse_lines(lines, on_reasoning, deadline_s=effective_deadline, t0=t0)
        except ProviderDeadlineError:
            raise
        except urllib.error.HTTPError as exc:
            elapsed = time.time() - t0
            detail = exc.read().decode("utf-8", errors="replace")
            retry_after = _parse_retry_after(exc.headers.get("Retry-After"))
            raise ProviderHTTPError(
                exc.code,
                f"HTTP {exc.code} from provider"
                f" [phase={self.phase} role={_scoped_role(self.role)} node={_scoped_node(self.node_id)}"
                f" elapsed={elapsed:.1f}s timeout={self.timeout}s]: {detail[:500]}",
                retry_after=retry_after,
            ) from exc
        except (urllib.error.URLError, TimeoutError, OSError) as exc:
            elapsed = time.time() - t0
            reason = getattr(exc, "reason", exc)
            raise ProviderError(
                f"provider request failed"
                f" [phase={self.phase} role={_scoped_role(self.role)} node={_scoped_node(self.node_id)}"
                f" elapsed={elapsed:.1f}s timeout={self.timeout}s]: {reason}"
            ) from exc


def _consume_sse_lines(
    lines: Iterable[str],
    on_reasoning: Callable[[str], None] | None,
    deadline_s: float | None = None,
    t0: float | None = None,
) -> dict[str, Any]:
    """B3-1: parse one SSE response body into the synthetic
    ``{choices: [{message: ...}]}`` shape ``_first_choice_message`` reads.
    Pure and sync so unit tests can feed it canned lines without a socket.

    Handles two bodies: proper SSE (``data:`` lines, ``[DONE]`` terminator,
    per-chunk ``delta.content`` / ``delta.reasoning_content`` /
    ``delta.reasoning``) and the degenerate case of an endpoint that
    ignores ``stream: true`` and returns a plain JSON body — then the whole
    body is parsed directly (an empty content buffer would otherwise fail
    validation and burn a reprompt).
    """
    content_parts: list[str] = []
    reasoning_parts: list[str] = []
    event_lines: list[str] = []
    raw_parts: list[str] = []
    usage_parts: dict[str, Any] = {}
    saw_sse = False
    start_time = t0 if t0 is not None else time.time()
    for line in lines:
        if deadline_s is not None and (time.time() - start_time) > deadline_s:
            raise ProviderDeadlineError(
                f"SSE stream wall-clock deadline exceeded ({time.time() - start_time:.1f}s > {deadline_s:.1f}s)",
                partial="".join(reasoning_parts) + "".join(content_parts),
            )
        raw_parts.append(line)
        if not line.startswith("data:"):
            if line == "" and event_lines:
                saw_sse = True
                _consume_sse_event(
                    "\n".join(event_lines), content_parts, reasoning_parts, on_reasoning, usage_parts
                )
                event_lines = []
            continue
        saw_sse = True
        data = line[len("data:"):].strip()
        if data == "[DONE]":
            event_lines = []
            break
        event_lines.append(data)
    if event_lines:
        _consume_sse_event("\n".join(event_lines), content_parts, reasoning_parts, on_reasoning, usage_parts)
    if not content_parts and not reasoning_parts and not saw_sse:
        parsed = json.loads("\n".join(raw_parts))
        return parsed
    res: dict[str, Any] = {
        "choices": [
            {
                "message": {
                    "content": "".join(content_parts),
                    "reasoning_content": "".join(reasoning_parts),
                }
            }
        ]
    }
    if usage_parts:
        res["usage"] = usage_parts
    return res


def _consume_sse_event(
    data: str,
    content_parts: list[str],
    reasoning_parts: list[str],
    on_reasoning: Callable[[str], None] | None,
    usage_parts: dict[str, Any] | None = None,
) -> None:
    try:
        chunk = json.loads(data)
    except json.JSONDecodeError:
        return
    if usage_parts is not None and isinstance(chunk, dict) and "usage" in chunk and isinstance(chunk["usage"], dict):
        usage_parts.update(chunk["usage"])
    choice = (chunk.get("choices") or [{}])[0]
    delta = choice.get("delta") or choice.get("message") or {}
    content = delta.get("content")
    if content:
        content_parts.append(content)
    reasoning = delta.get("reasoning_content") or delta.get("reasoning")
    if reasoning:
        reasoning_parts.append(reasoning)
        if on_reasoning is not None:
            on_reasoning(reasoning)


def _parse_retry_after(value: str | None) -> float | None:
    """``Retry-After`` as HTTP-date or seconds; seconds only — a date is
    ambiguous to parse without timezone tables. Caps at 60s on 5xx errors
    and caps at ``RATE_LIMIT_BACKOFFS[-1]`` (5h) on 429 rate limits."""
    if not value:
        return None
    try:
        return float(value)
    except ValueError:
        return None


def _first_choice_message(raw: dict[str, Any]) -> dict[str, Any]:
    choices = raw.get("choices") or [{}]
    return choices[0].get("message") or {}


def _first_choice_finish_reason(raw: dict[str, Any]) -> str:
    """``finish_reason`` for the first choice, "" when the host omits it."""
    choices = raw.get("choices") or [{}]
    first = choices[0] if isinstance(choices[0], dict) else {}
    return str(first.get("finish_reason") or first.get("stop_reason") or "")


def _hit_token_ceiling(raw: dict[str, Any], cap: int | None) -> bool:
    """Did this response stop because it ran out of output budget?

    PLAN-SWEEP-REPAIR.md §P3. ``finish_reason == "length"`` is the direct
    signal, but not every OpenAI-compatible host sets it, so a reported
    ``completion_tokens`` that reached the cap counts too. Without this a
    truncated response is indistinguishable from a broken one: 000-week armC
    seed1's three review attempts each returned exactly 4096 completion
    tokens and were reported as "invalid JSON: Expecting value: line 1
    column 1 (char 0)", which halted a run whose document was already complete.
    """
    if _first_choice_finish_reason(raw).lower() in ("length", "max_tokens"):
        return True
    if not cap:
        return False
    usage = raw.get("usage")
    if isinstance(usage, dict):
        try:
            return int(usage.get("completion_tokens", 0) or 0) >= cap
        except (TypeError, ValueError):
            return False
    return False


