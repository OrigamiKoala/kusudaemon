from __future__ import annotations

import asyncio
import os
import posixpath
import re
import shlex
import threading
import time
import uuid
from collections.abc import Callable
from pathlib import PurePath

from ..environment.base import Environment
from ..environment.remote_files import write_remote_text
from ..runtime_signals import detect_runtime_signals
from ..types import DEFAULT_TMP_DIR, DEFAULT_WORKSPACE_PATH, EpisodeBudget, EpisodeResult

_SECRET_NAME = r"(?:API[_-]?KEY|AUTH[_-]?TOKEN|ACCESS[_-]?TOKEN|SECRET|PASSWORD|TOKEN)"
_SECRET_VALUE = r"(?:'[^']*'|\"[^\"]*\"|\S+)"
_SECRET_PATTERNS = (
    re.compile(rf"\b([A-Za-z0-9_]*{_SECRET_NAME}\s*=){_SECRET_VALUE}", re.I),
    re.compile(rf"(--[A-Za-z0-9-]*{_SECRET_NAME}[= ]){_SECRET_VALUE}", re.I),
)


import json
from typing import Any

from ..v1.gates import estimate_tokens


def redact_secrets(text: str) -> str:
    """Mask credential values in text before it is logged or shown to a role."""
    for pattern in _SECRET_PATTERNS:
        text = pattern.sub(r"\1***REDACTED***", text)
    return text


def extract_tokens_from_actions_log(
    actions_log: str, prompt: str = "", visible_output: str = ""
) -> dict[str, Any]:
    """Extract token usage and cost metrics from an episode's action/trace log."""
    prompt_tokens = 0
    completion_tokens = 0
    reasoning_tokens = 0
    reported_total_tokens = 0
    cost_usd = 0.0
    has_usage = False

    for line in actions_log.splitlines():
        line = line.strip()
        if not line or not line.startswith("{"):
            continue
        try:
            rec = json.loads(line)
        except Exception:
            continue
        rtype = rec.get("type") or rec.get("role")
        if rtype == "usage":
            has_usage = True
            pt = int(rec.get("prompt_tokens", 0) or 0)
            ct = int(rec.get("completion_tokens", 0) or 0)
            rt = int(rec.get("reasoning_tokens", 0) or 0)
            tt = int(rec.get("total_tokens", 0) or 0)
            prompt_tokens += pt
            completion_tokens += ct
            reasoning_tokens += rt
            if tt > 0:
                reported_total_tokens += tt
            if rec.get("cost_usd") is not None:
                try:
                    cost_usd += float(rec["cost_usd"])
                except (ValueError, TypeError):
                    pass
        elif rtype == "message" and not has_usage:
            pt = int(rec.get("prompt_tokens", 0) or 0)
            ct = int(rec.get("completion_tokens", 0) or 0)
            if pt or ct:
                prompt_tokens += pt
                completion_tokens += ct

    if not has_usage and prompt_tokens == 0 and completion_tokens == 0:
        if prompt:
            prompt_tokens = max(1, estimate_tokens(prompt))
        out_text = visible_output or actions_log
        if out_text:
            completion_tokens = max(1, estimate_tokens(out_text))

    calc_total = prompt_tokens + completion_tokens + reasoning_tokens
    total_tokens = max(calc_total, reported_total_tokens)
    return {
        "prompt_tokens": prompt_tokens,
        "completion_tokens": completion_tokens,
        "reasoning_tokens": reasoning_tokens,
        "total_tokens": total_tokens,
        "cost_usd": cost_usd if has_usage and cost_usd > 0 else None,
    }


def classify_cli_failure(output: str) -> str:
    """Classify non-zero exit from CLI agent (PLAN-REVIEW-READ-LOOP.md §O1)."""
    low = output.lower()
    transport_patterns = (
        "cannot connect",
        "socket connection was closed",
        "connection refused",
        "connection reset",
        "connection error",
        "network error",
        "failed to connect",
        "econnrefused",
        "econnreset",
        "failed to get response headers",
        "response header",
        "gateway timeout",
        "bad gateway",
        "service unavailable",
        "internal server error",
        # OpenCode's shared sqlite store (~/.local/share/opencode/opencode.db)
        # when two CLIs boot in the same instant. The episode dies in <1 s
        # before any model call; it is contention, not a writer failure
        # (034-week s2 unit-01 lost an attempt to it on 2026-09-26).
        "database is locked",
        # NVIDIA NIM's generic server-side failure via the AI SDK. Observed
        # 2026-09-25 ending episodes ~2 s in; classified as ``error`` it cost
        # a real attempt each (200-menu-week s2 unit-01 lost 2 in 4 s).
        "failed to generate completions",
        # 2026-09-26: _agent_worker.py stopped the episode because the model's
        # output turned to garbage (degeneration.py). Seen from the first
        # token at small contexts and in bare OpenCode too, so it is the
        # endpoint's fault, not the writer's, and costs no attempt.
        "degenerate model output",
        # _agent_worker.py's opt-in first-output watchdog (item 10): the
        # provider produced nothing, which is not the writer's fault.
        "no first output",
    )
    if any(p in low for p in transport_patterns):
        return "transport"

    status_5xx_pattern = re.compile(
        r"(?:status(?:_code)?|http|code|error)[=:\s]+(500|502|503|504)\b|status\s+(500|502|503|504)\b|\b(500|502|503|504)\s+(server error|bad gateway|service unavailable|gateway timeout)\b",
        re.IGNORECASE,
    )
    if status_5xx_pattern.search(output):
        return "transport"

    rate_limit_patterns = (
        "rate limit",
        "rate_limit",
        "too many requests",
        "quota exceeded",
    )
    if any(p in low for p in rate_limit_patterns):
        return "throttled"

    status_429_pattern = re.compile(
        r"(?:status(?:_code)?|http|code|error)[=:\s]+429\b|status\s+429\b|\b429\s+too many requests\b",
        re.IGNORECASE,
    )
    if status_429_pattern.search(output):
        return "throttled"

    return "error"


_BOOT_LOCK = threading.Lock()
_LAST_BOOT = [0.0]


def _boot_gap_s() -> float:
    try:
        return max(0.0, float(os.getenv("KUSUDAEMON_OPENCODE_BOOT_GAP_S", "2.0")))
    except ValueError:
        return 2.0


async def _await_boot_slot() -> None:
    """Space agent-CLI process starts at least ``KUSUDAEMON_OPENCODE_BOOT_GAP_S``
    (default 2 s) apart, process-wide. Only adapters that set ``boot_gate``
    (OpenCode) wait.

    Every OpenCode episode opens the same sqlite store at boot, and two boots
    in the same instant fail with ``database is locked``. The round loop's
    index-based stagger only covered the first wave of one dispatch loop;
    the orchestrated loop, retries, probes and backend role calls all booted
    unspaced. Gating here covers every caller. A thread lock, because role
    calls run in worker threads with their own event loops."""
    gap = _boot_gap_s()
    if gap <= 0:
        return
    with _BOOT_LOCK:
        now = time.monotonic()
        slot = max(now, _LAST_BOOT[0] + gap)
        _LAST_BOOT[0] = slot
    if slot > now:
        await asyncio.sleep(slot - now)


class CommandAgentAdapter:
    # Overridden True by adapters whose CLI shares on-disk state at boot
    # (OpenCode's sqlite store); see ``_await_boot_slot``.
    boot_gate = False
    # Overridden True by adapters that can continue a prior run rather than
    # starting over (see ClaudeCodeAdapter). v0's runner falls back to a fresh
    # redispatch whenever this is False instead of erroring.
    supports_session_resume = False
    # Overridden True by adapters that can restrict which of their own tools
    # a single episode may use (see ClaudeCodeAdapter.allowed_tools). v1's
    # round loop builds one adapter per node via a caller-supplied factory,
    # so this flag is informational rather than load-bearing for that path.
    supports_tool_restriction = False
    # Overridden True by adapters whose agent can write files itself mid-
    # episode (see GptmeAdapter) -- v0/runner.py's post-episode fallback
    # (visible_output / actions_log) is a "last message becomes the
    # artifact" mechanism inherited from the original Claude Code/Codex
    # adapters (PLAN.md §D0; those backends were deleted 2026-08-09 and
    # re-added 2026-08-13 with has_file_tools=True — see claude_code.py/
    # codex.py) and must never run for one of these: an empty
    # out/<node>.md after a real file-writing episode is a genuine failure,
    # not raw log noise to paper over.
    has_file_tools = False

    def __init__(
        self,
        *,
        command_template: str,
        prompt_dir: str = f"{DEFAULT_TMP_DIR}/prompts",
        workspace_path: str = DEFAULT_WORKSPACE_PATH,
        visible_output_parser: Callable[[str], str] | None = None,
        hidden_paths: tuple[str, ...] = (),
        hidden_path_exceptions: tuple[str, ...] = (),
    ) -> None:
        self.command_template = command_template
        self.prompt_dir = prompt_dir.rstrip("/") or "."
        self.workspace_path = workspace_path.rstrip("/")
        self.visible_output_parser = visible_output_parser
        self.hidden_paths = tuple(hidden_paths)
        # PLAN.md §D2: a hidden entry like "out/" must still be hidden as a
        # directory, with an explicit carve-out naming the node's OWN two
        # paths (its artifact, its scratch dir) — not silently dropped from
        # the hidden list altogether, which is what let every Writer read
        # every other leaf's output (invariant 6).
        self.hidden_path_exceptions = tuple(hidden_path_exceptions)

    async def run_episode(
        self,
        prompt: str,
        env: Environment,
        budget: EpisodeBudget,
        live_trajectory_path: str | None = None,
        *,
        command_override: str | None = None,
    ) -> EpisodeResult:
        start = time.monotonic()
        # Never reuse one global prompt.md. A run owns its prompt directory and
        # every role episode gets a distinct filename, so concurrent harnesses
        # (and future concurrent roles within one harness) cannot overwrite the
        # input while an agent CLI is still reading it.
        prompt_path = posixpath.join(
            self.prompt_dir,
            f"{_episode_prompt_label(live_trajectory_path)}_{uuid.uuid4().hex[:12]}.md",
        )
        # PLAN-AUDIT-COST §A6-1: writer prompts now carry the notice inside
        # build_node_prompt (in the stable region, before any per-node
        # content) so it can join the cached prefix. This append remains for
        # callers that assemble their own prompts (v4 probes, structural
        # exploration), which never include the marker — a prompt that
        # already renders it must not receive it twice.
        notice = _hidden_paths_notice(self.hidden_paths, self.hidden_path_exceptions)
        if notice and _HIDDEN_PATHS_MARKER not in prompt:
            prompt = prompt + notice
        await write_remote_text(env, prompt_path, prompt)
        # Substituted by explicit replace, not str.format: templates embed literal
        # braces (e.g. Codex passes inline-TOML `-c` overrides) that format() would
        # try to interpret as placeholders.
        # command_override lets a subclass swap in a session-resume invocation
        # (e.g. `claude --resume <id>`) for one call without mutating the
        # instance's own command_template, which stays the fresh-dispatch form.
        command_body = command_override if command_override is not None else self.command_template
        for placeholder, value in (
            ("{prompt_path}", shlex.quote(prompt_path)),
            ("{timeout}", str(budget.max_duration_seconds)),
        ):
            command_body = command_body.replace(placeholder, value)
        command = f"cd {shlex.quote(self.workspace_path)} && {command_body}"
        if self.boot_gate:
            await _await_boot_slot()
        # When a live path is given (local runs), the environment mirrors stdout
        # to that file line-by-line so the TUI shows the trajectory live.
        result = await env.exec(
            command,
            timeout=budget.max_duration_seconds,
            tee_path=live_trajectory_path,
        )
        # PLAN-AUDIT.md §E20c: the prompt file's only job is being read by
        # the subprocess (`< {prompt_path}`), which has already happened by
        # the time env.exec returns above -- success, timeout, or error
        # alike. Left alone, one accumulates per episode *and* per retry
        # attempt (a large tree with retries reaches hundreds of these).
        # Best-effort and after the fact: a cleanup failure must never fail
        # an otherwise-completed episode.
        try:
            await env.exec(f"rm -f {shlex.quote(prompt_path)}", timeout=60)
        except Exception:
            pass

        duration_ms = int((time.monotonic() - start) * 1000)
        if result.termination_reason == "timeout":
            status = "timeout"
        elif result.exit_code != 0:
            combined = (result.stderr or "") + "\n" + (result.stdout or "")
            status = classify_cli_failure(combined)
        else:
            status = "done"
        stdout_log = result.stdout
        actions_log = stdout_log
        visible_output = (
            self.visible_output_parser(stdout_log).strip()
            if self.visible_output_parser is not None
            else ""
        )
        runtime_signals = detect_runtime_signals(stdout_log)
        token_info = extract_tokens_from_actions_log(actions_log, prompt, visible_output)
        if result.termination_reason == "timeout":
            error = f"Episode timed out after {budget.max_duration_seconds}s."
        else:
            error = redact_secrets(result.stderr[-2000:]) if result.exit_code != 0 else None
        return EpisodeResult(
            status=status,
            actions_log=actions_log,
            error=error,
            duration_ms=duration_ms,
            metadata={
                "command": redact_secrets(command),
                "prompt_path": prompt_path,
                "exit_code": result.exit_code,
                "termination_reason": result.termination_reason,
                "actions_log_chars": len(actions_log),
                "trajectory_format": "jsonl",
                "assistant_visible_output": visible_output,
                "runtime_signals": runtime_signals,
                "actions_log_diagnostics_only": bool(
                    self.visible_output_parser is not None and not visible_output
                ),
                "stderr_chars": len(result.stderr),
                "stderr_tail": redact_secrets(result.stderr[-2000:]),
                "prompt_tokens": token_info["prompt_tokens"],
                "completion_tokens": token_info["completion_tokens"],
                "reasoning_tokens": token_info["reasoning_tokens"],
                "total_tokens": token_info["total_tokens"],
                "cost_usd": token_info["cost_usd"],
            },
        )


_HIDDEN_PATHS_MARKER = "Harness-owned paths (off limits):"


def _hidden_paths_notice_block(hidden_paths: tuple[str, ...]) -> str:
    """The constant half of the notice (PLAN-AUDIT-COST §A6-1): the hidden
    list itself, identical across every node of a run, so it can sit in the
    stable, prefix-cacheable region of the prompt (``pipeline/prompts.py``).
    The per-node exception lines are rendered separately by
    ``_hidden_path_exceptions_block``."""
    if not hidden_paths:
        return ""
    listed = "\n".join(f"- {path}" for path in hidden_paths)
    return (
        f"\n\n{_HIDDEN_PATHS_MARKER}\n"
        f"{listed}\n"
        "These hold this run's own logs, prompts, and harness state — including "
        "OTHER nodes' artifacts and scratch notes. Never read, list, search, or "
        "modify them, and never treat their contents as task input or evidence."
    )


def _hidden_path_exceptions_block(hidden_path_exceptions: tuple[str, ...]) -> str:
    """The per-node half of the notice (§A6-1): the node's own two paths,
    carved out of the constant hidden list above (PLAN.md §D2)."""
    if not hidden_path_exceptions:
        return ""
    exceptions = "\n".join(f"- {path}" for path in hidden_path_exceptions)
    return (
        "\n\nException — these are yours, and writing to them is the point:\n"
        f"{exceptions}"
    )


def _hidden_paths_notice(
    hidden_paths: tuple[str, ...], hidden_path_exceptions: tuple[str, ...] = ()
) -> str:
    """Tell the agent to stay out of the harness's own run directories.

    The run's logs, prompts and harness state may sit inside the workspace. They
    are not task content, and reading them would leak other roles' context —
    including, critically, ``out/`` and ``scratch/``: those hold every OTHER
    leaf's finished artifact and working notes, and a Writer that reads a
    sibling's output produces exactly the correlated drift cross-agent
    isolation (PLAN.md §2 invariant 6) exists to prevent. ``hidden_path_exceptions``
    carves out the node's own two paths — the ones it is *supposed* to
    touch — so the instruction to write ``out/<id>.md`` and the notice to
    stay out of ``out/`` don't contradict each other (§D0/§D2).
    """
    return _hidden_paths_notice_block(hidden_paths) + _hidden_path_exceptions_block(
        hidden_path_exceptions
    )


def _episode_prompt_label(live_trajectory_path: str | None) -> str:
    """Derive a readable round/role label without relying on it for uniqueness."""
    if not live_trajectory_path:
        return "episode_agent"
    path = PurePath(live_trajectory_path)
    role = path.stem
    suffix = "_raw_trajectory"
    if role.endswith(suffix):
        role = role[: -len(suffix)]
    round_name = path.parent.name if re.fullmatch(r"round_\d+", path.parent.name) else "episode"
    label = f"{round_name}_{role}"
    return re.sub(r"[^A-Za-z0-9_.-]+", "_", label).strip("._") or "episode_agent"
