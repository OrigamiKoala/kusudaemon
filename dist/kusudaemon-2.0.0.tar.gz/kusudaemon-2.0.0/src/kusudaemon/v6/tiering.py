"""Tier classification and phase routing (PLAN.md §A4, §B2).

**The problem this exists to solve.** Deterministic size signals cannot
separate "remove a div" from "rewrite the auth layer" in a 500-file repo —
both have the same file count. Only reading the goal against the shape of
the work object can. But if the sizing step itself costs a survey, it has
defeated its own purpose. The resolution: one bounded, advisory model call
(``estimate_scope``), mapped into a tier by a pure code table
(``classify``). The model estimates; the harness decides; every cap is
code, never a model's opinion about whether something "feels too big"
(``CLAUDE.md`` §2 invariant 2, carried into PLAN.md §A2 invariant 2's
amended form).

Two invariants this module exists to serve (PLAN.md §A2, amended set):

8. **Cost scales with the task.** The phase list for a run is computed by
   code from a tier, never chosen by a model and never fixed at seven.
9. **Escalation is one-way.** A run's tier may rise at runtime; it never
   falls. ``escalate`` is the single function that enforces this, so every
   call site (``pipeline/driver.py``, the CLI's ``escalate`` command)
   shares one monotonicity guarantee instead of re-deriving it.

**Signals vs. estimate.** ``Signals`` (§A4.1) is entirely free — string
matching plus fields already computed on ``WorkObject`` (v6/work_object.py,
§B1) at construction time, no model call, no file reads beyond what
measuring the work object already did. ``estimate_scope`` (§A4.2) is
exactly one ``complete_json`` call, same pattern as
``v2/planner.py:plan_level`` / ``v2/intake.py``'s question calls: a system
prompt, one user message, a capped-output schema. It never sees file
contents — a digest of ``top_dirs`` plus a truncated, content-free file
listing (``work_object.iter_workspace_paths``), the same "labels and token
counts, never source" rule ``CLAUDE.md`` §3 states for the Planner.

**``named_paths`` is deliberately coarse.** It checks only whether a
work object's *top-level directory names* appear in the goal text, not
individual file names — a full re-walk to match filenames would double the
I/O ``measure_workspace`` already paid at WorkObject-construction time for
every large-repo run, just to compute one advisory signal. Refining this to
real filename matching is natural follow-up once §B4's probes exist to do
real exploration instead of a free heuristic standing in for it.
"""

from __future__ import annotations

import os
import re
from dataclasses import dataclass
from typing import Any, Callable, Literal

from ..v1.gates import estimate_tokens
from ..v1.provider import call_scope
from ..roles.protocol import RoleProvider
from ..v2.intake import QuestionSet
from .work_object import WorkObject, iter_workspace_paths

Tier = Literal["T0", "T1", "T2", "T3"]

_TIERS_BY_RANK: tuple[Tier, ...] = ("T0", "T1", "T2", "T3")
_TIER_RANK: dict[str, int] = {tier: rank for rank, tier in enumerate(_TIERS_BY_RANK)}

# §A4.1's exact word lists.
_BREADTH_MARKERS = (
    "every", "all", "entire", "across", "refactor", "audit", "migrate",
    "rewrite", "each", "throughout",
)
_OUTPUT_MARKERS = ("chapter", "section", "per file", "for each", "suite")

_BREADTH_RE = re.compile(
    r"\b(" + "|".join(re.escape(word) for word in _BREADTH_MARKERS) + r")\b",
    re.IGNORECASE,
)
_OUTPUT_RE = re.compile(
    r"\b(" + "|".join(re.escape(word) for word in _OUTPUT_MARKERS) + r")\b",
    re.IGNORECASE,
)

_NUMERIC_WORDS = (
    r"\d+",
    "one", "two", "three", "four", "five", "six", "seven", "eight", "nine", "ten",
    "eleven", "twelve", "thirteen", "fourteen", "fifteen", "sixteen", "seventeen",
    "eighteen", "nineteen", "twenty", "thirty", "forty", "fifty", "sixty", "seventy",
    "eighty", "ninety", "hundred", "thousand",
)
_NUMERIC_TARGET_NOUNS = (
    "chapters?", "sections?", "parts?", "modules?", "files?", "words?",
    "pages?", "steps?", "items?", "tests?", "suites?", "benchmarks?",
    "subtasks?", "components?", "deliverables?", "entries?", "blocks?",
)
_NUMERIC_TARGET_RE = re.compile(
    r"\b(?:"
    + "|".join(_NUMERIC_WORDS)
    + r")\s+(?:per\s+\w+|"
    + "|".join(_NUMERIC_TARGET_NOUNS)
    + r")\b",
    re.IGNORECASE,
)

_TARGET_COUNT_RE = re.compile(
    r"\b("
    + "|".join(_NUMERIC_WORDS)
    + r")\s+(?:per\s+\w+|"
    + "|".join(_NUMERIC_TARGET_NOUNS)
    + r")\b",
    re.IGNORECASE,
)

_WORD_TO_NUM: dict[str, int] = {
    "one": 1, "two": 2, "three": 3, "four": 4, "five": 5,
    "six": 6, "seven": 7, "eight": 8, "nine": 9, "ten": 10,
    "eleven": 11, "twelve": 12, "thirteen": 13, "fourteen": 14, "fifteen": 15,
    "sixteen": 16, "seventeen": 17, "eighteen": 18, "nineteen": 19, "twenty": 20,
    "thirty": 30, "forty": 40, "fifty": 50, "sixty": 60, "seventy": 70,
    "eighty": 80, "ninety": 90, "hundred": 100, "thousand": 1000,
}

_PLAN_MIN_OUTPUT_UNITS = 8


def _declared_target_count(goal: str) -> int:
    """PLAN-BENCH-INTEGRITY.md §1.4 & PLAN-TOKEN-ACCOUNTING.md §I1: re-exported from tokens.expected_units."""
    from ..tokens import expected_units
    return expected_units(goal) or 0


@dataclass(frozen=True)
class Signals:
    """PLAN.md §A4.1 — free, code-only, no model call."""

    work_tokens: int
    work_files: int
    goal_tokens: int
    named_paths: tuple[str, ...] = ()
    breadth_markers: int = 0
    output_markers: int = 0
    output_targets: int = 0


def _named_paths(goal: str, work: WorkObject) -> tuple[str, ...]:
    """Coarse containment check against ``work.top_dirs`` — see module
    docstring for why this stops at directory names rather than a full
    filename match."""
    if work.kind != "workspace" or not work.top_dirs:
        return ()
    lowered = goal.lower()
    return tuple(
        name for name, _tokens in work.top_dirs if name != "." and name.lower() in lowered
    )


def measure_signals(goal: str, work: WorkObject) -> Signals:
    """PLAN.md §A4.1: pure, deterministic. String matching over the goal
    plus fields already sitting on ``WorkObject`` — nothing here reads a
    file or calls a model."""
    return Signals(
        work_tokens=work.est_tokens,
        work_files=work.files,
        goal_tokens=estimate_tokens(goal),
        named_paths=_named_paths(goal, work),
        breadth_markers=len(_BREADTH_RE.findall(goal)),
        output_markers=len(_OUTPUT_RE.findall(goal)),
        output_targets=len(_NUMERIC_TARGET_RE.findall(goal)),
    )


FILES_TOUCHED_VALUES = ("1", "few", "many", "unknown")

# PLAN-REVIEW-LATENCY-STATUS.md §8.4a: model-supplied evidence about the *kind*
# of work — never a phase/review bypass (that stays rejected per §8.3), only
# an input to the code table in _classify_raw. "unknown" preserves today's
# behavior exactly.
WORK_KIND_VALUES = ("document", "procedure", "code-edit", "unknown")


def _normalize_work_kind(value: object) -> str:
    text = str(value).strip().lower() if value is not None else "unknown"
    return text if text in WORK_KIND_VALUES else "unknown"


@dataclass(frozen=True)
class ScopeEstimate:
    """PLAN.md §A4.2 — the one advisory model call's parsed output."""

    files_touched: str = "unknown"
    artifacts: int = 1
    answerable_without_exploration: bool = False
    ambiguities: tuple[str, ...] = ()
    objections: tuple[str, ...] = ()
    work_kind: str = "unknown"


# 2026-09-26: was 50. LongGenBench goals ask for 52 weekly menus or 100
# floors, so the model had to reconcile "the goal says 52" with "the schema
# says at most 50", and one classify call collapsed into "0. 0. 0. ..." while
# deliberating exactly that. Tiering only asks whether the count is 1 or
# above 8, so a large bound changes no tier.
ARTIFACTS_MAX = 1000

ESTIMATE_SCHEMA: dict[str, Any] = {
    "type": "object",
    "required": ["files_touched", "artifacts", "answerable_without_exploration"],
    "additionalProperties": False,
    "properties": {
        "files_touched": {"type": "string", "enum": list(FILES_TOUCHED_VALUES)},
        "artifacts": {"type": "integer", "minimum": 1, "maximum": ARTIFACTS_MAX},
        "answerable_without_exploration": {"type": "boolean"},
        "work_kind": {"type": "string", "enum": list(WORK_KIND_VALUES)},
        "ambiguities": {
            "type": "array",
            "items": {"type": "string", "maxLength": 200},
            "maxItems": 8,
        },
        "objections": {
            "type": "array",
            "items": {"type": "string", "maxLength": 200},
            "maxItems": 8,
        },
    },
}

_ESTIMATE_SYSTEM_PROMPT = (
    "You are the scope estimator in a long-horizon task harness (PLAN.md "
    "§A4). You never see file contents -- only the goal and a digest of the "
    "target work object (directory names, token counts, a truncated, "
    "content-free file listing). Estimate: how many distinct artifacts the "
    "goal implies producing (the full count, however large); whether it plausibly touches exactly one file, "
    "a few, many, or you cannot tell (files_touched); whether you could "
    "answer it correctly right now without exploring the work object "
    "further (answerable_without_exploration); what kind of work this "
    "primarily is -- producing a document (document), performing operations "
    "or procedures in an environment such as running commands, restarting "
    "services, or applying patches (procedure), editing code (code-edit), "
    "or you cannot tell (work_kind, default unknown); and list any genuine "
    "ambiguities or objections -- contradictions in the goal, missing "
    "information you would need -- empty arrays if there are none. This "
    "estimate is advisory only; the harness, not you, decides what happens "
    "next. Respond with a single JSON object only."
)


def _work_digest(work: WorkObject, *, outline_limit: int = 40) -> str:
    lines = [f"work kind: {work.kind}", f"files: {work.files}, est_tokens: {work.est_tokens}"]
    if work.top_dirs:
        lines.append("top-level directories by size:")
        for name, tokens in work.top_dirs[:20]:
            lines.append(f"  {name}/  (~{tokens} tokens)")
    if work.kind == "workspace":
        outline = iter_workspace_paths(work, limit=outline_limit)
        if outline:
            lines.append("file tree outline (truncated, paths only, no content):")
            lines.extend(f"  {path}" for path in outline)
    return "\n".join(lines)


def estimate_scope(
    goal: str,
    work: WorkObject,
    provider: RoleProvider,
    *,
    on_reasoning: Callable[[str], None] | None = None,
) -> ScopeEstimate:
    """PLAN.md §A4.2: exactly one ``complete_json`` call. Advisory only —
    ``classify`` below is what actually decides the tier. This is the
    legacy narrow call (used by tests and callers that want the estimate
    alone); the pipeline's classify phase uses ``estimate_scope_full``
    (A5-2), which folds intake round-1 question generation into this same
    call."""
    messages = [
        {"role": "system", "content": _ESTIMATE_SYSTEM_PROMPT},
        {
            "role": "user",
            "content": f"Goal: {goal}\n\nWork object digest:\n{_work_digest(work)}",
        },
    ]
    # 2026-09-26: stamped so cost rows say "classify" (they said "unknown")
    # and ``KUSUDAEMON_REASONING_CLASSIFY`` applies.
    with call_scope(role="classify"):
        payload = provider.complete_json(messages, ESTIMATE_SCHEMA, on_reasoning=on_reasoning)
    return ScopeEstimate(
        files_touched=str(payload.get("files_touched", "unknown")),
        artifacts=int(payload.get("artifacts", 1)),
        answerable_without_exploration=bool(payload.get("answerable_without_exploration", False)),
        ambiguities=tuple(str(item) for item in (payload.get("ambiguities") or [])),
        objections=tuple(str(item) for item in (payload.get("objections") or [])),
        work_kind=_normalize_work_kind(payload.get("work_kind", "unknown")),
    )


# A5-2 (IMPLEMENTATION-PLAN-COST-AND-LIVE.md): the merged classify call.
# ``ESTIMATE_SCHEMA``'s free-text ``ambiguities`` disappears — the model
# decides in one pass which ambiguities need the operator (those become
# ``questions`` with default assumptions, intake's consumable form) and
# which are genuine conflicts (those become structured ``objections``),
# exactly the split ``build_question_set`` used to perform in a second
# round trip over nearly identical context. Round 2 of intake still calls
# ``build_question_set`` separately (it needs the transcript), so nothing
# is lost — one call and one goal+digest context saved on every T1+ run.
FULL_SCOPE_SCHEMA: dict[str, Any] = {
    "type": "object",
    "required": [
        "files_touched",
        "artifacts",
        "answerable_without_exploration",
        "questions",
        "objections",
    ],
    "additionalProperties": False,
    "properties": {
        "files_touched": {"type": "string", "enum": list(FILES_TOUCHED_VALUES)},
        "artifacts": {"type": "integer", "minimum": 1, "maximum": ARTIFACTS_MAX},
        "answerable_without_exploration": {"type": "boolean"},
        "work_kind": {"type": "string", "enum": list(WORK_KIND_VALUES)},
        "questions": {
            "type": "array",
            "items": {
                "type": "object",
                "required": ["id", "text", "default_assumption"],
                "additionalProperties": False,
                "properties": {
                    "id": {"type": "string", "minLength": 1, "maxLength": 40},
                    "text": {"type": "string", "minLength": 1, "maxLength": 200},
                    "default_assumption": {"type": "string", "maxLength": 300},
                },
            },
            "maxItems": 4,
        },
        "objections": {
            "type": "array",
            "items": {
                "type": "object",
                "required": ["claim", "why", "options"],
                "additionalProperties": False,
                "properties": {
                    "claim": {"type": "string", "minLength": 1, "maxLength": 200},
                    "why": {"type": "string", "maxLength": 300},
                    "options": {
                        "type": "array",
                        "items": {"type": "string", "maxLength": 150},
                        "maxItems": 4,
                    },
                },
            },
            "maxItems": 8,
        },
    },
}

_FULL_SCOPE_SYSTEM_PROMPT = (
    _ESTIMATE_SYSTEM_PROMPT
    + " Additionally, decide which of the goal's genuine ambiguities need "
    "the operator's input: for each, emit a short clarifying question with "
    "a default_assumption (what to assume if nobody answers — a real "
    "fallback decision, not a restatement of the question). Omit any "
    "ambiguity that does not actually need the operator — an empty "
    "questions list is a valid, good answer. Separately restate every "
    "genuine objection as a concrete conflict: claim (what's contradictory "
    "or missing), why (the actual tension), and up to 4 options for how "
    "the operator could resolve it (options may be empty for a pure "
    "objection with no natural menu of fixes). Respond with a single JSON "
    "object only."
)


def estimate_scope_full(
    goal: str,
    work: WorkObject,
    provider: RoleProvider,
    *,
    on_reasoning: Callable[[str], None] | None = None,
    streaming: bool = False,
) -> tuple[ScopeEstimate, QuestionSet]:
    """A5-2: the merged classify + intake-round-1 call — one
    ``complete_json`` where the legacy ``estimate_scope`` plus a
    ``build_question_set`` round-trip used to be two. Returns the
    ``ScopeEstimate`` (``ambiguities``/``objections`` populated from the
    structured output so ``classify``'s T0 check keeps working) and the
    round-1 ``QuestionSet`` the driver stores in ``tier.json`` so a resume
    can re-ask the exact same questions without re-calling the model.
    """
    from ..v2.intake import IntakeObjection, IntakeQuestion

    messages = [
        {"role": "system", "content": _FULL_SCOPE_SYSTEM_PROMPT},
        {
            "role": "user",
            "content": f"Goal: {goal}\n\nWork object digest:\n{_work_digest(work)}",
        },
    ]
    with call_scope(role="classify"):
        payload = provider.complete_json(
            messages, FULL_SCOPE_SCHEMA, on_reasoning=on_reasoning, streaming=streaming
        )
    questions = tuple(
        IntakeQuestion(
            id=str(item.get("id") or f"q{index + 1}"),
            text=str(item.get("text", "")),
            default_assumption=str(item.get("default_assumption", "")),
        )
        for index, item in enumerate(payload.get("questions") or [])
    )
    objections = tuple(
        IntakeObjection(
            claim=str(item.get("claim", "")),
            why=str(item.get("why", "")),
            options=tuple(str(option) for option in (item.get("options") or [])),
        )
        for item in payload.get("objections") or []
    )
    estimate = ScopeEstimate(
        files_touched=str(payload.get("files_touched", "unknown")),
        artifacts=int(payload.get("artifacts", 1)),
        answerable_without_exploration=bool(payload.get("answerable_without_exploration", False)),
        ambiguities=tuple(question.text for question in questions),
        objections=tuple(objection.claim for objection in objections),
        work_kind=_normalize_work_kind(payload.get("work_kind", "unknown")),
    )
    return estimate, QuestionSet(questions=questions, objections=objections)


# PLAN.md §A4.3's T2 row ("artifacts <= 8 or work_tokens < 150k") defines
# the line between "cheap enough to fly without planning" and "needs a
# spine". §E28 (2026-08-13): T0/T1 must sit on the same side of that line
# -- before, a 4.4M-token corpus whose estimate said "1 artifact, few
# files" classified T1 and its single node ran blind (no spine, no inputs,
# the writer never saw the corpus). A corpus that big falls through to T2,
# where survey builds a spine and the planner partitions it.
_T2_WORK_TOKENS_CEILING = 150_000
_T1_WORK_TOKENS_CEILING = 3_320
_T1_WORK_FILES_CEILING = 8


def _numeric_output_target(goal: str) -> bool:
    return bool(_NUMERIC_TARGET_RE.search(goal))


def _measured_small(signals: Signals, estimate: ScopeEstimate, goal: str = "") -> bool:
    """PLAN-WORKSPACE-MODE.md §R1: Floor is a conjunction over input AND output evidence.
    Declines escalation only when every signal agrees the work is small."""
    has_target = bool(signals.output_targets > 0 or (goal and _numeric_output_target(goal)))
    return (
        signals.work_tokens < _T1_WORK_TOKENS_CEILING
        and signals.work_files <= _T1_WORK_FILES_CEILING
        and signals.breadth_markers == 0
        and signals.output_markers == 0
        and not has_target
        and estimate.artifacts <= 1
    )


def _files_touched_from_signals(signals: Signals) -> str:
    if signals.work_files <= 1:
        return "1"
    if signals.work_files <= 8:
        return "few"
    return "many"


def output_capacity(goal: str) -> tuple[int | None, int | None]:
    """Declared output volume vs. what one leaf holds: ``(declared, per_leaf)``.

    Both halves are measured, never estimated. ``declared`` is
    ``tokens.expected_units`` -- a regex over the goal's own text.
    ``per_leaf`` is ``v2/survey.units_per_leaf_capacity`` -- leaf token budget
    divided by the goal's own declared unit size. Neither costs a model call
    or a file read, which is what lets the tier table use them (§A4.1's rule
    that signals are free; only ``estimate_scope`` may cost a call).

    Returns ``(None, None)`` when the goal declares no unit count, which
    leaves every caller's behaviour exactly as it was before this existed."""
    declared = _declared_target_count(goal)
    if not declared:
        return None, None
    from ..v2.survey import units_per_leaf_capacity

    return declared, units_per_leaf_capacity(goal)


def _output_fits_one_leaf(goal: str) -> bool:
    """Whether a single node could hold this goal's whole declared output."""
    declared, per_leaf = output_capacity(goal)
    if declared is None or per_leaf is None:
        return True
    return declared <= per_leaf


def _classify_raw_inner(
    signals: Signals, estimate: ScopeEstimate, goal: str = ""
) -> Tier:
    # §A4.3's table has always had an INPUT-volume axis (``work_tokens``
    # against ``_T2_WORK_TOKENS_CEILING``) and, until 2026-09-18, no OUTPUT
    # one. That asymmetry is what put every "write 100 floors" run on the
    # single-node path: ``files_touched`` and ``artifacts`` describe the
    # SHAPE of the output (one file, one artifact) and are silent about its
    # VOLUME, so a goal asking for 100 units in one file read identically to
    # one asking for a paragraph in one file. The T0/T1 rows now carry the
    # same conjunct the §E28 comment below states for input: a single node
    # may only be chosen when a single node could actually hold the work.
    #
    # This is deliberately NOT a floor bolted on top of the table, and not a
    # threshold on the unit count. A floor would override the table with a
    # policy; a threshold would need a magic number. Both are answered by
    # arithmetic the harness already does -- ``output_capacity`` divides the
    # leaf token budget by the goal's own declared unit size, and the tiler
    # in ``v2/survey`` tiles with the identical number. "Write 8 sections"
    # still classifies T1 because 8 sections genuinely fit one leaf.
    fits_one_leaf = _output_fits_one_leaf(goal)
    if (
        estimate.artifacts == 1
        and estimate.files_touched == "1"
        and signals.work_tokens < _T2_WORK_TOKENS_CEILING
        and signals.breadth_markers == 0
        and fits_one_leaf
        and not estimate.ambiguities
        and not estimate.objections
    ):
        return "T0"
    if (
        estimate.artifacts == 1
        and estimate.files_touched in ("1", "few")
        and signals.work_tokens < _T2_WORK_TOKENS_CEILING
        and fits_one_leaf
    ):
        return "T1"
    if estimate.artifacts <= 8 and signals.work_tokens < _T2_WORK_TOKENS_CEILING:
        return "T2"
    return "T3"


def _classify_raw(signals: Signals, estimate: ScopeEstimate, goal: str = "") -> Tier:
    """PLAN.md §A4.3's table, first match wins.

    PLAN-BENCH-INTEGRITY.md §1.4a: A single output FILE is not a single unit
    of WORK. The output-volume conjunct in ``_classify_raw_inner`` is the
    durable form of that rule, opt-in via ``KUSUDAEMON_TIER_OUTPUT_SIGNALS=1``.
    Off by default since 2026-09-26: it moved every LongGenBench cell off T1
    (bash-append writer, 21/21 at >=99 %) onto decomposed leaves, which
    finished clean in ~5 of ~27 runs since 09-14. It depends on per-unit stub
    files for decomposed leaves (``KUSUDAEMON_UNIT_STUBS``): without them a
    bash-less ``_PROSE`` leaf clobbers its single file with one ``write`` per
    unit.
    """
    if os.getenv("KUSUDAEMON_TIER_OUTPUT_SIGNALS", "0") != "1":
        return _classify_raw_inner(signals, estimate)
    return _classify_raw_inner(signals, estimate, goal=goal)


def classify(
    signals: Signals,
    estimate: ScopeEstimate,
    *,
    on_event: Callable[[dict[str, Any]], None] | None = None,
    log: Any = None,
    goal: str = "",
) -> Tier:
    """PLAN.md §A4.3: "`unknown` in `files_touched` forces at least T2 — an
    estimator that cannot tell is exactly the case that needs exploration."
    Applied as an override on top of the table rather than folded into it,
    so the table itself stays a plain reading of §A4.3's rows.

    PLAN-WORKSPACE-MODE.md §K0, §R1: Guard the escalation behind
    KUSUDAEMON_TIER_TRUST_SIGNALS. A model estimate of 'unknown' must not
    outrank measured small signals."""
    if log is not None and on_event is None:
        if hasattr(log, "emit"):
            on_event = lambda ev: log.emit(ev.get("type"), **{k: v for k, v in ev.items() if k != "type"})
        elif hasattr(log, "append"):
            on_event = lambda ev: log.append(ev)

    if estimate.files_touched == "unknown":
        if os.getenv("KUSUDAEMON_TIER_TRUST_SIGNALS", "0") == "1" and _measured_small(signals, estimate, goal=goal):
            effective_ft = _files_touched_from_signals(signals)
            effective_estimate = ScopeEstimate(
                files_touched=effective_ft,
                artifacts=estimate.artifacts,
                answerable_without_exploration=estimate.answerable_without_exploration,
                ambiguities=estimate.ambiguities,
                objections=estimate.objections,
                work_kind=estimate.work_kind,
            )
            tier = _classify_raw(signals, effective_estimate, goal=goal)
            if on_event is not None:
                on_event(
                    {
                        "type": "tier_escalation_declined",
                        "work_tokens": signals.work_tokens,
                        "work_files": signals.work_files,
                        "breadth_markers": signals.breadth_markers,
                        "output_markers": signals.output_markers,
                        "output_targets": signals.output_targets,
                        "work_kind": estimate.work_kind,
                        "ceiling_tokens": _T1_WORK_TOKENS_CEILING,
                        "ceiling_files": _T1_WORK_FILES_CEILING,
                        "tier_kept": tier,
                    }
                )
            return _apply_work_kind_floor(tier, estimate, on_event)
        tier = _classify_raw(signals, estimate, goal=goal)
        return _apply_work_kind_floor(tier_max(tier, "T2"), estimate, on_event)

    tier = _classify_raw(signals, estimate, goal=goal)
    _emit_output_capacity(signals, estimate, goal, tier, on_event)
    return _apply_work_kind_floor(tier, estimate, on_event)


def _emit_output_capacity(
    signals: Signals,
    estimate: ScopeEstimate,
    goal: str,
    tier: Tier,
    on_event: Callable[[dict[str, Any]], None] | None,
) -> None:
    """Record the output-volume axis whenever it moved the answer, so a run
    that decomposed can be told apart from one that decomposed *because the
    declared output did not fit a leaf* without re-deriving the arithmetic."""
    if on_event is None:
        return
    declared, per_leaf = output_capacity(goal)
    if declared is None or per_leaf is None or declared <= per_leaf:
        return
    without = _classify_raw_inner(signals, estimate)
    if without == tier:
        return
    on_event(
        {
            "type": "tier_output_capacity",
            "declared_units": declared,
            "units_per_leaf": per_leaf,
            "leaves_implied": -(-declared // per_leaf),
            "tier_without_axis": without,
            "tier": tier,
        }
    )


def _apply_work_kind_floor(
    tier: Tier,
    estimate: ScopeEstimate,
    on_event: Callable[[dict[str, Any]], None] | None,
) -> Tier:
    """PLAN-REVIEW-LATENCY-STATUS.md §8.4a: the table maps model-supplied
    evidence to a tier — monotone only. An explicit ``procedure`` kind floors
    at T1: operations work (commands, services, patches) has a blast radius
    file counts cannot bound, and T0's treeless path skips the intake where
    destructive-command ambiguity gets resolved. T1 keeps the single-node
    direct path, so this costs no decomposition. Every other kind
    (including ``unknown``) leaves the table result untouched, and the model
    can never lower a floor — only code does that."""
    if estimate.work_kind == "procedure" and _TIER_RANK[tier] < _TIER_RANK["T1"]:
        if on_event is not None:
            on_event(
                {
                    "type": "tier_work_kind_floor",
                    "work_kind": estimate.work_kind,
                    "tier_raised_to": "T1",
                }
            )
        return "T1"
    return tier


def tier_max(a: Tier, b: Tier) -> Tier:
    """The higher of two tiers — used for ``--tier``'s floor-not-ceiling
    override (PLAN.md §B2: "forces a floor, never a ceiling — invariant
    9")."""
    return a if _TIER_RANK[a] >= _TIER_RANK[b] else b


# PLAN.md §A4.3: the *maximal* phase list per tier. `intake`/`explore` are
# conditionally no-ops at runtime (`pipeline/driver.py`'s `_phase_intake`/
# `_phase_explore` read `needs_intake`/`needs_explore` back out of
# `tier.json` and short-circuit to a logged no-op when the trigger isn't
# met) rather than being omitted from the tuple outright — this mirrors the
# *existing* `_phase_done` idiom (a phase always appears in the driver's
# phase machinery; whether it does real work is a runtime, disk-backed
# decision) instead of inventing a second, parallel skip mechanism. See
# `pipeline/driver.py`'s phase-loop docstring for the full reasoning and the
# resulting phase-name choices ("explore" folding in what "survey" does
# until §B4's real probes exist; "verify" as T0's dedicated review+finalize
# step distinct from T1-3's "review").
_PHASES_BY_TIER: dict[Tier, tuple[str, ...]] = {
    "T0": ("classify", "execute", "verify"),
    "T1": ("classify", "intake", "explore", "execute", "review"),
    "T2": ("classify", "intake", "explore", "plan", "execute", "review", "assemble"),
    "T3": (
        "classify", "intake", "explore", "plan", "pilot", "research",
        "execute", "review", "assemble",
    ),
}


def phases_for(tier: Tier) -> tuple[str, ...]:
    """PLAN.md §A4.3/§B2: the phase list for a run, computed by code from
    its tier — never chosen by a model, never fixed at seven
    (``CLAUDE.md``'s old ``PHASES`` constant this replaces)."""
    try:
        return _PHASES_BY_TIER[tier]
    except KeyError as exc:
        raise ValueError(f"unknown tier: {tier!r}") from exc


# PLAN.md §A4.4: every trigger but "operator" names its own floor tier
# directly (the amendment/regenerate/split triggers all target a specific
# tier regardless of where the run currently sits, same as the table says);
# "operator" is the one relative trigger (+1 tier), because an operator
# hitting "escalate" on a T0 run means "give this more room," not "jump
# straight to T3."
_ESCALATION_TARGET: dict[str, Tier] = {
    "size_defect_retry": "T2",
    "majority_regenerate": "T3",
    # PLAN.md §B5 (not built yet): a node's accepted split proposal
    # promotes T2 -> T3. This target is correct and tested in isolation
    # (test_v6_tiering.py) but nothing calls `escalate(tier,
    # "split_accepted")` yet -- runtime split (§A8) doesn't exist. Wiring a
    # call site for a mechanism that isn't built would be fake, not deferred
    # honestly.
    "split_accepted": "T3",
}


# PLAN.md §A4.3's table: T1 -> 2, T2 -> 6. T0 has no explore phase at all
# (phases_for("T0") is classify/execute/verify — no "explore" entry), so
# 0 here is not a real cap being exercised, just an honest value for a
# tier that never calls max_explorers_for in practice. T3's row lists only
# "depth cap 4, node cap 400" under Caps — no explorer number — so PLAN.md
# §B4 leaves the exact figure to this implementation. 8 is chosen
# deliberately, not left "unbounded" or "= number of top-level units":
# either of those would defeat the entire point of a cap (a 200-directory
# monorepo would still dispatch 200 probes under "= units", and
# "unbounded" needs no comment). One more than T2's cap keeps the ordering
# "richer tiers get a little more room to explore" without inventing a
# second, unrelated scale — revisit once real eval data (PLAN.md
# §C5/§C6) exists to justify a different number.
_MAX_EXPLORERS: dict[Tier, int] = {"T0": 0, "T1": 2, "T2": 6, "T3": 8}


def max_explorers_for(tier: Tier) -> int:
    """PLAN.md §A4.3/§A6/§B4: the hard per-tier cap on structural-exploration
    probe episodes — one of the three code-side cost fences §A6 requires
    (a per-probe episode budget, this cap, and the 300-token finding cap,
    ``v4/research.py``'s ``RESEARCH_FINDING_TOKEN_CAP``). Bounds cost by
    tier, never by corpus size: a work object with 4 top-level units and one
    with 400 both dispatch at most this many probes."""
    try:
        return _MAX_EXPLORERS[tier]
    except KeyError as exc:
        raise ValueError(f"unknown tier: {tier!r}") from exc


def escalate(current: Tier, trigger: str) -> Tier:
    """PLAN.md §A2 invariant 9: the result is never lower than ``current``,
    for *every* trigger, including ones not wired to any call site yet.
    Unknown triggers raise rather than silently no-op — a typo'd trigger
    name must not look like a successful, harmless escalation."""
    if trigger == "operator":
        target = _TIERS_BY_RANK[min(_TIER_RANK[current] + 1, len(_TIERS_BY_RANK) - 1)]
    elif trigger in _ESCALATION_TARGET:
        target = _ESCALATION_TARGET[trigger]
    else:
        raise ValueError(f"unknown escalation trigger: {trigger!r}")
    return target if _TIER_RANK[target] > _TIER_RANK[current] else current
