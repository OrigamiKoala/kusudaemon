"""Planner — recursive, one level at a time (PLAN.md §4.3).

Same small-output rule as everything else: the model never sees more than
one slice of the spine at a time — unit labels and token counts only,
never source content (§3: "Planner never sees source content"). Call #1
sees the whole spine and emits a flat top-level partition (8-12 children,
never nested JSON — parent implied by the call). The harness, not the
model, runs the **leaf gate** (§4.3) on each child; anything that fails
gets its own separate planner call over just its slice of the spine.
Recurse to ``DEFAULT_DEPTH_CAP`` with a ``DEFAULT_NODE_CAP`` total-node
ceiling, both enforced in code — §2 invariant 2: "gated by code, not by
model judgment about whether a task 'feels' too big."

Leaves carry ``depends_on=[]``. §4.5: "Freezing the contract after the
pilot makes the remaining leaves genuinely independent" — planning never
wires up leaf-to-leaf ordering; there is nothing for it to depend on until
the pilot/contract phase runs (this same v2 build, ``pilot.py``), and that
wiring is a later pipeline-driver concern, not the planner's.

v2 has no node-type template system yet (§15.4's skills-as-templates
direction). Leaves come out with the generic gates v1 already ships
(``nonempty``, ``max_tokens:N``) and no judgment items — richer per-shape
rubrics derived from the frozen contract are future wiring.
"""

from __future__ import annotations

import re as _re
from dataclasses import dataclass
from typing import Any, Callable

from ..v0.events import EventLog
from ..roles.protocol import RoleProvider
from ..v1.tree import NodeBudget, TaskNode, TaskTree
from .survey import OUTPUT_UNIT_NOUNS, SpineUnit, pluralize_unit_noun

# "<Nouns> N to M" / "<noun> N-M" in a leaf brief. Built from the survey's own
# noun tuple (plus the generic "unit"), singular and plural, so a label the
# survey writes is always a label the planner can read back.
_RANGE_NOUNS = sorted(
    {form for noun in (*OUTPUT_UNIT_NOUNS, "unit") for form in (noun, pluralize_unit_noun(noun))},
    key=len,
    reverse=True,
)
UNIT_RANGE_RE = _re.compile(
    r"\b(?:[A-Za-z]+\s+)*(?:" + "|".join(_RANGE_NOUNS) + r")s?\s+(\d+)\s*(?:-|–|to)\s*(\d+)\b",
    _re.IGNORECASE,
)


def leaf_units_expected(
    brief: str, slice_units: list[SpineUnit], goal: str = ""
) -> tuple[int | None, str | None]:
    """How many output units a leaf over ``slice_units`` must produce
    (PLAN-SWEEP-REPAIR.md §K2).

    Order of authority:
    1. The spine's own per-unit counts, when every unit in the slice carries
       one. A synthesized output spine computed them from the goal's declared
       target, and a planner candidate tiles whole spine units, so their sum is
       exact. Re-deriving the count from prose is what went wrong before: the
       000-week brief "Entrys 21 to 40" missed the range pattern and fell
       through to ``expected_units_info``, whose named-ordinal rule read
       "Entrys 21" as a count of 21 (units_expected 1/21/41 for leaves of
       20/20/12), demoted the gate to a warning, and armed the §L1 retry to
       "append units 13-41" into another leaf's weeks.
    2. An explicit "<Nouns> N to M" range in the brief.
    3. ``expected_units_info`` over the brief, then any partial spine counts.
    4. §R1: ``expected_units_info`` over the GOAL, and only when ``goal`` is
       passed -- ``build_tree`` passes it for a leaf that covers the entire
       spine, i.e. the only leaf in the tree. Without this the T2 path had no
       route from "the goal declares 100 floors" to a gate at all: the count
       came from the spine, and a structurally-chunked spine (the shape you get
       when KUSUDAEMON_OUTPUT_SPINE is off and the goal is one short chunk) has
       one unit labelled "Opening section" carrying units_expected=None. The T1
       path (``v6/direct.build_single_node``) has always read the goal; the two
       single-leaf paths now agree. A leaf that covers the whole spine is by
       definition the only leaf, so this can never smear a whole-document count
       across the leaves of a partitioned plan.
    """
    from ..tokens import expected_units_info

    counts = [getattr(u, "units_expected", None) for u in slice_units]
    if counts and all(isinstance(c, int) and c > 0 for c in counts):
        return sum(counts), "declared"

    m_range = UNIT_RANGE_RE.search(brief or "")
    if m_range:
        start, end = int(m_range.group(1)), int(m_range.group(2))
        if end >= start:
            return end - start + 1, "declared"

    u_info, u_src = expected_units_info(brief or "")
    if u_info is not None and u_info > 0:
        return u_info, u_src
    u_sum = sum(c for c in counts if isinstance(c, int) and c > 0)
    if u_sum > 0:
        return u_sum, "declared"

    if goal:
        g_info, g_src = expected_units_info(goal)
        if g_info is not None and g_info > 0:
            return g_info, g_src
    return None, None

DEFAULT_DEPTH_CAP = 4
DEFAULT_NODE_CAP = 400
DEFAULT_TOOL_CALL_CAP = 15  # §4.3 leaf gate: "estimated tool calls <= K (start K=15)"
DEFAULT_TOKEN_BUDGET = 50_000  # matches v1's NodeBudget default
DEFAULT_TOP_LEVEL_MIN_CHILDREN = 8
DEFAULT_TOP_LEVEL_MAX_CHILDREN = 12

_SHAPES = ["prose-dominant", "derivation-dominant", "problem-set-dominant", "reference-dominant", "code-dominant"]

def _make_partition_schema(with_probes: bool) -> dict[str, Any]:
    props: dict[str, Any] = {
        "children": {
            "type": "array",
            "minItems": 1,
            "items": {
                "type": "object",
                "required": ["id", "brief", "unit_start", "unit_end", "estimated_calls", "shape"],
                "additionalProperties": False,
                "properties": {
                    "id": {"type": "string", "maxLength": 40},
                    "brief": {"type": "string", "maxLength": 300},
                    "unit_start": {"type": "integer", "minimum": 0},
                    "unit_end": {"type": "integer", "minimum": 0},
                    "estimated_calls": {"type": "integer", "minimum": 1},
                    "shape": {"type": "string", "enum": _SHAPES},
                    "depends_on": {
                        "type": "array",
                        "items": {"type": "string", "maxLength": 40},
                        "maxItems": 3,
                    },
                },
            },
        },
    }
    if with_probes:
        props["probes"] = {
            "type": "array",
            "maxItems": 2,
            "items": {
                "type": "object",
                "required": ["node_id", "slug", "question"],
                "additionalProperties": False,
                "properties": {
                    "node_id": {"type": "string", "minLength": 1, "maxLength": 64},
                    "slug": {"type": "string", "minLength": 1, "maxLength": 64},
                    "question": {"type": "string", "minLength": 1, "maxLength": 400},
                    "kind": {"type": "string", "maxLength": 32},
                },
            },
        }
    return {
        "type": "object",
        "required": ["children"],
        "additionalProperties": False,
        "properties": props,
    }


PARTITION_SCHEMA: dict[str, Any] = _make_partition_schema(with_probes=True)
PARTITION_SCHEMA_NO_PROBES: dict[str, Any] = _make_partition_schema(with_probes=False)

_SYSTEM_PROMPT = (
    "You are the Planner in a long-horizon task harness. You never see "
    "source content — only a spine of unit labels and token counts. Given "
    "a slice of that spine (0-indexed within this call only), partition it "
    "into a flat list of children covering every unit in the slice exactly "
    "once, in order, with no gaps and no overlap. Prefer 8-12 children when "
    "the slice is the full top-level spine; use fewer for a smaller slice — "
    "never split a slice that is already small into more pieces than it "
    "needs. Each child gets: a short brief stating its done-condition as "
    "one checkable sentence, a shape classification, and your estimate of "
    "how many tool calls a writer would need to produce it. Children are "
    "always a flat list; the parent is implied by the call itself, never "
    "nested JSON. Respond with a single JSON object only."
)


@dataclass
class Candidate:
    id: str
    brief: str
    shape: str
    unit_start: int
    unit_end: int
    estimated_calls: int
    tokens: int
    depends_on: list[str] | None = None

    def __post_init__(self) -> None:
        if self.depends_on is None:
            self.depends_on = []


def _render_slice(
    units: list[SpineUnit],
    unit_summary_for: Callable[[SpineUnit], str] | None = None,
) -> str:
    """One line per unit — label and token count only, per §3: "Planner
    never sees source content." PLAN.md §A7 point 3/§B4 adds one more line
    per unit *only* when ``unit_summary_for`` returns something: the
    ≤300-token capped finding a structural-exploration probe already wrote
    (``v4/research.py``'s ``RESEARCH_FINDING_TOKEN_CAP``), never source —
    the harness already paid for that summary before this call, and it's
    strictly a better partition input than the label alone."""
    lines = []
    for i, unit in enumerate(units):
        line = f"{i}: {unit.label} ({unit.tokens} tokens)"
        summary = unit_summary_for(unit) if unit_summary_for is not None else ""
        if summary:
            line += f"\n   summary: {summary}"
        lines.append(line)
    return "\n".join(lines)


def plan_level(
    units: list[SpineUnit],
    provider: RoleProvider,
    *,
    top_level: bool,
    unit_summary_for: Callable[[SpineUnit], str] | None = None,
    on_reasoning: Callable[[str], None] | None = None,
    probe_sink: list[dict[str, Any]] | None = None,
    streaming: bool = False,
) -> list[Candidate]:
    """A5-3 (IMPLEMENTATION-PLAN-COST-AND-LIVE.md): when ``probe_sink`` is
    given, any ``probes`` the model returns are normalized and appended to
    it — folded into this call instead of a later separate
    ``plan_probes`` windowed call. Normalization mirrors
    ``v4/probe_planner.py:_ask_one_window`` (kind validated post-hoc with
    ``"web"`` fallback), so a sink entry is interchangeable with that
    module's ``ProbeSuggestion`` dicts. The returned list is unchanged —
    the sink is a pure out-parameter, never read here."""
    hint = (
        f"{DEFAULT_TOP_LEVEL_MIN_CHILDREN}-{DEFAULT_TOP_LEVEL_MAX_CHILDREN} children"
        if top_level
        else "as few children as the slice actually needs"
    )
    messages = [
        {"role": "system", "content": _SYSTEM_PROMPT},
        {
            "role": "user",
            "content": (
                f"Slice has {len(units)} units, indices 0..{len(units) - 1}. Target: {hint}.\n\n"
                + _render_slice(units, unit_summary_for)
            ),
        },
    ]
    payload = provider.complete_json(messages, PARTITION_SCHEMA, on_reasoning=on_reasoning, streaming=streaming)
    if probe_sink is not None:
        raw_probes = payload.get("probes")
        if isinstance(raw_probes, list):
            for raw in raw_probes:
                if not isinstance(raw, dict):
                    continue
                node_id = str(raw.get("node_id") or "").strip()
                slug = str(raw.get("slug") or "").strip()
                question = str(raw.get("question") or "").strip()
                if not node_id or not slug or not question:
                    continue
                kind = str(raw.get("kind") or "web").strip() or "web"
                if kind not in ("web", "workspace", "corpus"):
                    kind = "web"
                probe_sink.append(
                    {"node_id": node_id, "slug": slug, "question": question, "kind": kind}
                )
    candidates = []
    for child in payload["children"]:
        unit_start = max(0, min(int(child["unit_start"]), len(units) - 1))
        unit_end = max(unit_start, min(int(child["unit_end"]), len(units) - 1))
        tokens = sum(unit.tokens for unit in units[unit_start : unit_end + 1])
        raw_deps = child.get("depends_on")
        deps = [str(d).strip() for d in raw_deps if str(d).strip()] if isinstance(raw_deps, list) else []
        candidates.append(
            Candidate(
                id=str(child["id"]),
                brief=str(child["brief"]),
                shape=str(child["shape"]),
                unit_start=unit_start,
                unit_end=unit_end,
                estimated_calls=int(child["estimated_calls"]),
                tokens=tokens,
                depends_on=deps,
            )
        )
    return candidates


def leaf_gate(
    candidate: Candidate,
    *,
    token_budget: int = DEFAULT_TOKEN_BUDGET,
    tool_call_cap: int = DEFAULT_TOOL_CALL_CAP,
    trust_estimated_calls: bool = True,
) -> tuple[bool, list[str]]:
    """§4.3: a node may be a leaf only if *all* hold. Checked by the harness,
    never asserted by the model. ("Produces exactly one named artifact" and
    "done-condition expressible as one checkable sentence" are enforced by
    construction elsewhere in this module — every candidate gets exactly
    one artifact path and a required, length-capped brief — so this checks
    the two conditions that are genuinely data-dependent.)"""
    reasons = []
    if not candidate.brief.strip():
        reasons.append("no checkable done-condition")
    if candidate.tokens > token_budget:
        reasons.append(f"inputs {candidate.tokens} tokens exceed budget {token_budget}")
    if trust_estimated_calls and candidate.estimated_calls > tool_call_cap:
        reasons.append(f"estimated {candidate.estimated_calls} calls exceed cap {tool_call_cap}")
    return (not reasons, reasons)


class _NodeBudget:
    """Mutable node-count ceiling shared across the recursion (§2 invariant
    2: caps are enforced by code, not offered to the model as a choice)."""

    def __init__(self, node_cap: int) -> None:
        self.node_cap = node_cap
        self.count = 0

    def take(self) -> bool:
        if self.count >= self.node_cap:
            return False
        self.count += 1
        return True


def _gap_candidate(
    unit_start: int, unit_end: int, units: list[SpineUnit], tool_call_cap: int
) -> Candidate:
    span = units[unit_start : unit_end + 1]
    return Candidate(
        id=f"gap{unit_start}-{unit_end}",
        brief=f"Produce the artifact for {span[0].label} (automatic gap fill).",
        shape="prose-dominant",
        unit_start=unit_start,
        unit_end=unit_end,
        estimated_calls=min(tool_call_cap, max(1, len(span))),
        tokens=sum(unit.tokens for unit in span),
    )


def _repair_partition(
    candidates: list[Candidate],
    units: list[SpineUnit],
    *,
    tool_call_cap: int,
) -> tuple[list[Candidate], str | None]:
    """§11.4: never trust the model's partition to tile its slice. The
    prompt asks for "every unit exactly once, in order" and the harness used
    to take that on faith — a model emitting [0-3], [5-9] silently dropped
    unit 4 from the tree and therefore from ``assembly/main.md``, with no
    event. Truncate overlaps first-claim-wins, drop double-covered children,
    and insert a forced candidate over every uncovered span. Returns the
    repaired list and an event detail string, or ``None`` when the model's
    partition was already exact."""
    if not units:
        return [], None
    detail: list[str] = []
    accepted: list[Candidate] = []
    covered_through = -1
    for cand in candidates:
        start, end = cand.unit_start, cand.unit_end
        if start <= covered_through:
            if end <= covered_through:
                detail.append(
                    f"duplicate coverage {cand.id} [{start}..{end}] dropped"
                )
                continue
            detail.append(
                f"overlap {cand.id} [{start}..{end}] truncated to "
                f"[{covered_through + 1}..{end}]"
            )
            start = covered_through + 1
        if start > end:
            detail.append(f"out-of-order {cand.id} [{start}..{end}] dropped")
            continue
        accepted.append(
            Candidate(
                id=cand.id,
                brief=cand.brief,
                shape=cand.shape,
                unit_start=start,
                unit_end=end,
                estimated_calls=cand.estimated_calls,
                tokens=cand.tokens,
                depends_on=cand.depends_on,
            )
        )
        covered_through = end
    repaired: list[Candidate] = []
    next_unit = 0
    for cand in accepted:
        if cand.unit_start > next_unit:
            repaired.append(_gap_candidate(next_unit, cand.unit_start - 1, units, tool_call_cap))
            detail.append(f"gap [{next_unit}..{cand.unit_start - 1}] filled with a forced leaf")
        repaired.append(cand)
        next_unit = cand.unit_end + 1
    if next_unit <= len(units) - 1:
        repaired.append(_gap_candidate(next_unit, len(units) - 1, units, tool_call_cap))
        detail.append(f"gap [{next_unit}..{len(units) - 1}] filled with a forced leaf")
    return repaired, "; ".join(detail) or None


def _sanitize_dependencies(
    candidates: list[Candidate],
    emit: Callable[[dict[str, Any]], None] | None = None,
) -> None:
    sibling_ids = {c.id for c in candidates}
    for c in candidates:
        valid_deps = []
        for dep in (c.depends_on or []):
            if dep in sibling_ids and dep != c.id:
                valid_deps.append(dep)
            else:
                if emit is not None:
                    emit(
                        {
                            "node_id": c.id,
                            "type": "planner_dep_dropped",
                            "dep": dep,
                            "reason": "unknown or self dependency",
                        }
                    )
        c.depends_on = valid_deps

    adj = {c.id: list(c.depends_on) for c in candidates}
    for c in candidates:
        visited: set[str] = set()
        stack: list[str] = list(c.depends_on)
        has_cycle = False
        while stack:
            curr = stack.pop()
            if curr == c.id:
                has_cycle = True
                break
            if curr not in visited:
                visited.add(curr)
                stack.extend(adj.get(curr, []))
        if has_cycle:
            c.depends_on = []
            adj[c.id] = []
            if emit is not None:
                emit(
                    {
                        "node_id": c.id,
                        "type": "planner_dep_dropped",
                        "reason": "cycle detected",
                    }
                )


def build_tree(
    units: list[SpineUnit],
    provider: RoleProvider,
    *,
    depth_cap: int = DEFAULT_DEPTH_CAP,
    node_cap: int = DEFAULT_NODE_CAP,
    token_budget: int = DEFAULT_TOKEN_BUDGET,
    tool_call_cap: int = DEFAULT_TOOL_CALL_CAP,
    default_gates: tuple[str, ...] = ("nonempty",),
    input_path_for: Callable[[SpineUnit], str] | None = None,
    log: EventLog | None = None,
    unit_summary_for: Callable[[SpineUnit], str] | None = None,
    on_reasoning: Callable[[str], None] | None = None,
    probe_sink: list[dict[str, Any]] | None = None,
    streaming: bool = False,
    code_tile_planner: bool = False,
    trust_estimated_calls: bool = True,
    goal: str = "",
) -> TaskTree:
    """Recurse level-at-a-time from the full spine to a flat set of leaf
    TaskNodes. Depth cap, node cap, and a size floor (a one-unit slice
    cannot be usefully split further) are all harness decisions that force
    a leaf regardless of what the leaf gate says — the model is never asked
    whether it has hit a limit.

    ``input_path_for`` resolves a unit to whatever a leaf's ``inputs`` entry
    should actually be (PLAN-zeromem.md §7) — e.g. a materialized file path
    under ``spine/`` — without this module ever knowing about run-directory
    layout itself. Left ``None``, a leaf's inputs are bare unit ids, today's
    behavior.

    ``log``, when supplied, receives the harness-side repair events:
    ``planner_partition_repaired`` (the model's partition did not tile its
    slice — §11.4) and ``planner_node_cap_reached`` (the node cap dropped
    remaining units). Both were silent before; both are structural
    corrections, not model judgment.

    ``unit_summary_for`` (PLAN.md §A7 point 3/§B4) resolves a unit to its
    structural-exploration probe summary, if one exists — threaded through
    to every ``plan_level`` call at every recursion depth, not just the
    top-level one, so a deeper slice re-planned after a failing leaf still
    sees whatever summary its units have."""
    nodes: dict[str, TaskNode] = {}
    budget = _NodeBudget(node_cap)
    cap_event_emitted = False
    # §R1: the goal's declared unit count is authority only for a leaf that
    # covers the entire spine -- which is to say, only when the plan collapsed
    # to one node.
    spine_size = len(units)

    def emit(event: dict[str, Any]) -> None:
        if log is not None:
            log.append({"role": "harness", "round": 0, **event})

    def unique_id(node_id: str) -> str:
        if node_id not in nodes:
            return node_id
        suffix = 2
        while f"{node_id}-{suffix}" in nodes:
            suffix += 1
        return f"{node_id}-{suffix}"

    def add_leaf(
        node_id: str,
        candidate: Candidate,
        slice_units: list[SpineUnit],
        deps: list[str] | None = None,
        budgeted: bool = False,
    ) -> str | None:
        nonlocal cap_event_emitted
        if not budgeted and not budget.take():
            if not cap_event_emitted and slice_units:
                cap_event_emitted = True
                emit(
                    {
                        "node_id": node_id,
                        "type": "planner_node_cap_reached",
                        "detail": (
                            f"node cap {node_cap} reached; "
                            f"units {slice_units[0].id}..{slice_units[-1].id} dropped"
                        ),
                    }
                )
            return None
        node_id = unique_id(node_id)
        gates = [*default_gates, f"max_tokens:{token_budget}"]
        inputs = (
            [input_path_for(unit) for unit in slice_units]
            if input_path_for is not None
            else [unit.id for unit in slice_units]
        )
        from ..tokens import extract_unit_delimiter

        covers_whole_spine = bool(goal) and len(slice_units) == spine_size
        units_expected, units_source = leaf_units_expected(
            candidate.brief, slice_units, goal=goal if covers_whole_spine else ""
        )

        delimiter = extract_unit_delimiter(candidate.brief)
        if not delimiter and slice_units:
            for u in slice_units:
                if getattr(u, "unit_delimiter", None):
                    delimiter = u.unit_delimiter
                    break
        if not delimiter and covers_whole_spine:
            delimiter = extract_unit_delimiter(goal)

        warn_gates: list[str] = []
        if units_expected and units_expected > 0:
            units_gate = f"units_min:{units_expected}@{delimiter}" if delimiter else f"units_min:{units_expected}"
            if units_source == "declared":
                gates.append(units_gate)
            else:
                warn_gates.append(units_gate)

            m_range = UNIT_RANGE_RE.search(candidate.brief or "")
            if m_range:
                r_lo, r_hi = int(m_range.group(1)), int(m_range.group(2))
                if r_hi >= r_lo:
                    range_gate = f"units_range:{r_lo}-{r_hi}@{delimiter}" if delimiter else f"units_range:{r_lo}-{r_hi}"
                    if units_source == "declared":
                        gates.append(range_gate)
                    else:
                        warn_gates.append(range_gate)

        node = TaskNode(
            id=node_id,
            brief=candidate.brief,
            artifact=f"out/{node_id}.md",
            gates=gates,
            warn_gates=warn_gates,
            shape=candidate.shape,
            inputs=inputs,
            budget=NodeBudget(
                tokens=token_budget,
                calls=tool_call_cap,
                units_expected=units_expected,
                unit_delimiter=delimiter,
            ),
            depends_on=list(deps if deps is not None else (candidate.depends_on or [])),
        )
        # PLAN.md §C1: apply the shape's node-type template's gates /
        # judgment / rubric to the leaf. Warn-severity gates ship into
        # ``node.warn_gates`` (not ``node.gates``) so a failing
        # warn-gate never blocks the node from reaching "passed" — see
        # ``v6/templates.py``'s module docstring for the "ship warn
        # first, graduate after measuring" rationale.
        from ..v6.templates import apply_template_to_node

        apply_template_to_node(node)
        nodes[node_id] = node
        return node_id

    def forced_leaf(slice_units: list[SpineUnit], node_id: str, reason: str) -> str | None:
        tokens = sum(unit.tokens for unit in slice_units)
        brief = (
            f"Produce the artifact for {slice_units[0].label}."
            if reason == slice_units[0].label
            else f"Produce the artifact for {slice_units[0].label} ({reason})."
        )
        # LONGGENBENCH-RESULTS-2026-09 §4.1 item 11: when the plan collapses to
        # one leaf covering the whole spine (a goal with no countable unit),
        # that leaf's brief is the only thing the planner hands the writer, and
        # "Produce the artifact for <label>" says nothing about the goal. Carry
        # the goal itself, as the T1 direct node does (brief=goal).
        if goal.strip() and len(slice_units) == spine_size and spine_size <= 1:
            brief = f"{brief}\n\nGoal:\n{goal.strip()}"
        candidate = Candidate(
            id=node_id,
            brief=brief,
            shape="prose-dominant",
            unit_start=0,
            unit_end=len(slice_units) - 1,
            estimated_calls=min(tool_call_cap, max(1, len(slice_units))),
            tokens=tokens,
        )
        return add_leaf(node_id, candidate, slice_units)

    def recurse(slice_units: list[SpineUnit], depth: int, path: str) -> list[str]:
        """Build this slice's level and recurse. Returns the ids of every
        leaf this slice produced, so the caller can re-point ``depends_on``
        edges that named a recursed candidate at its descendant leaves (a
        recursed candidate never becomes a node itself — its children
        replace it)."""
        nonlocal cap_event_emitted
        if not slice_units:
            return []
        if len(slice_units) <= 1:
            leaf_id = forced_leaf(slice_units, path or slice_units[0].id, "single unit, cannot split further")
            return [leaf_id] if leaf_id else []
        if depth >= depth_cap:
            leaf_id = forced_leaf(slice_units, path or f"depth{depth}", "depth cap reached")
            return [leaf_id] if leaf_id else []
        if all(getattr(u, "units_expected", None) is not None for u in slice_units):
            leaves = []
            for unit in slice_units:
                leaf_id = forced_leaf([unit], f"{path}.{unit.id}" if path else unit.id, unit.label)
                if leaf_id:
                    leaves.append(leaf_id)
            return leaves
        if code_tile_planner:
            if all(u.tokens >= token_budget for u in slice_units):
                leaves = []
                for unit in slice_units:
                    leaf_id = forced_leaf([unit], f"{path}.{unit.id}" if path else unit.id, "unit exceeds budget alone")
                    if leaf_id:
                        leaves.append(leaf_id)
                return leaves
            if sum(u.tokens for u in slice_units) <= token_budget:
                leaf_id = forced_leaf(slice_units, path or slice_units[0].id, "slice fits budget")
                return [leaf_id] if leaf_id else []

        candidates = plan_level(
            slice_units,
            provider,
            top_level=(depth == 0),
            unit_summary_for=unit_summary_for,
            on_reasoning=on_reasoning,
            streaming=streaming,
            # A5-3: probes are collected only from the top-level call —
            # only there does a model-provided node id equal the final
            # tree id. Deeper calls' children become ``path.child`` ids
            # the model never saw, so their suggestions could never
            # resolve; collecting-and-dropping would be fake confidence.
            probe_sink=probe_sink if depth == 0 else None,
        )
        if not candidates:
            leaf_id = forced_leaf(slice_units, path or f"depth{depth}", "planner returned no children")
            return [leaf_id] if leaf_id else []
        candidates, partition_detail = _repair_partition(
            candidates, slice_units, tool_call_cap=tool_call_cap
        )
        if partition_detail:
            emit(
                {
                    "node_id": path or "<root>",
                    "type": "planner_partition_repaired",
                    "detail": partition_detail,
                    "slice_size": len(slice_units),
                }
            )
        _sanitize_dependencies(candidates, emit)

        # §D28: model-emitted depends_on names *candidate* ids at this
        # level; the final node ids are path-prefixed leaves (candidate
        # "opening" under path "c01" becomes node "c01.opening"), and a
        # recursed candidate never becomes a node at all. An unwritten edge
        # dangles — the next TaskTree.load fails with "depends_on unknown
        # node" (observed live on a 12-chapter textbook plan: 'c08' ->
        # 'c02' where c02 was recursed into children). So classify every
        # candidate first, recursing the non-leaves to collect their
        # descendant leaf ids, then add the leaves with their edges
        # rewritten: a dep on a leaf sibling re-points at the sibling's
        # final id; a dep on a recursed sibling re-points at every
        # descendant leaf (conservative — preserves the ordering the model
        # asked for without guessing which child holds the content).
        leaf_final: dict[str, str] = {}
        recursed_leaves: dict[str, list[str]] = {}
        pending_leaves: list[tuple[Candidate, list[SpineUnit]]] = []

        def rewritten_deps(candidate: Candidate) -> list[str]:
            deps: list[str] = []
            for dep in candidate.depends_on or []:
                if dep in leaf_final:
                    deps.append(leaf_final[dep])
                    emit(
                        {
                            "node_id": candidate.id,
                            "type": "planner_dep_rewritten",
                            "dep": dep,
                            "to": leaf_final[dep],
                            "reason": "leaf id prefixed",
                        }
                    )
                elif dep in recursed_leaves:
                    deps.extend(recursed_leaves[dep])
                    emit(
                        {
                            "node_id": candidate.id,
                            "type": "planner_dep_rewritten",
                            "dep": dep,
                            "to": recursed_leaves[dep],
                            "reason": "target recursed into leaves",
                        }
                    )
                else:
                    emit(
                        {
                            "node_id": candidate.id,
                            "type": "planner_dep_dropped",
                            "dep": dep,
                            "reason": "unknown node after rewrite",
                        }
                    )
            return deps

        for candidate in candidates:
            node_id = f"{path}.{candidate.id}" if path else candidate.id
            child_units = slice_units[candidate.unit_start : candidate.unit_end + 1]
            is_leaf, _reasons = leaf_gate(
                candidate,
                token_budget=token_budget,
                tool_call_cap=tool_call_cap,
                trust_estimated_calls=trust_estimated_calls,
            )
            if is_leaf or depth + 1 >= depth_cap or len(child_units) <= 1:
                if budget.take():
                    leaf_final[candidate.id] = unique_id(node_id)
                    pending_leaves.append((candidate, child_units))
                elif not cap_event_emitted and child_units:
                    cap_event_emitted = True
                    emit(
                        {
                            "node_id": node_id,
                            "type": "planner_node_cap_reached",
                            "detail": (
                                f"node cap {node_cap} reached; "
                                f"units {child_units[0].id}..{child_units[-1].id} dropped"
                            ),
                        }
                    )
            else:
                recursed_leaves[candidate.id] = recurse(child_units, depth + 1, node_id)
            if budget.count >= node_cap:
                if not cap_event_emitted:
                    cap_event_emitted = True
                    emit(
                        {
                            "node_id": node_id,
                            "type": "planner_node_cap_reached",
                            "detail": (
                                f"node cap {node_cap} reached; further candidates "
                                f"in this slice dropped"
                            ),
                        }
                    )
                break

        leaf_ids: list[str] = []
        for candidate, child_units in pending_leaves:
            final_id = add_leaf(
                leaf_final[candidate.id],
                candidate,
                child_units,
                deps=rewritten_deps(candidate),
                budgeted=True,
            )
            if final_id is not None:
                leaf_ids.append(final_id)
        return leaf_ids

    recurse(units, 0, "")
    # §D28 belt-and-suspenders: no edge may dangle, whatever the model
    # emitted (duplicate ids, renames the rewrite could not resolve).
    # TaskTree.load rejects such a tree; drop the edge here instead so the
    # plan phase can never ship an unloadable tree.json.
    for node in nodes.values():
        kept = [dep for dep in node.depends_on if dep in nodes]
        if len(kept) != len(node.depends_on):
            emit(
                {
                    "node_id": node.id,
                    "type": "planner_dep_dropped",
                    "dep": [d for d in node.depends_on if d not in nodes],
                    "reason": "unknown node after rewrite",
                }
            )
            node.depends_on = kept
    return TaskTree(nodes=nodes)
